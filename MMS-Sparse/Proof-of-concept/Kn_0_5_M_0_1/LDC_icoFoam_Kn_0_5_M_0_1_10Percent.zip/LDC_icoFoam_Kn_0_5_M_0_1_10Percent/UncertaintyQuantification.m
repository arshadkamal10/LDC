
clear all;
close all;

%% Noisy Data %%

Kn = 0.5;
M = 0.1;
h=1;    
N=50; %500; 
N1 = N;
N2 = N;

datastart = 801000;
interval = 30000;

filename = sprintf(['../../../../DSMC/Kn_0_5_M_0_1/prop_grid.%d.dat'], datastart+interval);
    
fileID = fopen(filename);
for k=1:9
    fgets(fileID);
end
C = textscan(fileID,'%f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64');
fclose(fileID);

xc_vec = C{1}';
yc_vec = C{2}';
f_U_vec = C{3}';
f_V_vec = C{4}';
f_Tau_xx_vec = C{5}';
f_Tau_yy_vec = C{6}';
f_Tau_xy_vec = C{7}';
f_Press_vec = C{8}';
f_Mrho_vec = C{9}';
f_Ttra_vec = C{10}';

%First sorting by x:
[xc_vec_sorted,I] = sort(xc_vec);
yc_vec_sorted = yc_vec(I);
f_U_vec_sorted = f_U_vec(I);
f_V_vec_sorted = f_V_vec(I);
f_Tau_xx_vec_sorted = f_Tau_xx_vec(I);
f_Tau_yy_vec_sorted = f_Tau_yy_vec(I);
f_Tau_xy_vec_sorted = f_Tau_xy_vec(I);
f_Press_vec_sorted = f_Press_vec(I);
f_Mrho_vec_sorted = f_Mrho_vec(I);
f_Ttra_vec_sorted = f_Ttra_vec(I);

%Second sorting by y:
[yc_vec_sorted2,I2] = sort(yc_vec_sorted);
xc_vec_sorted2 = xc_vec_sorted(I2);
f_U_vec_sorted2 = f_U_vec_sorted(I2);
f_V_vec_sorted2 = f_V_vec_sorted(I2);
f_Tau_xx_vec_sorted2 = f_Tau_xx_vec_sorted(I2);
f_Tau_yy_vec_sorted2 = f_Tau_yy_vec_sorted(I2);
f_Tau_xy_vec_sorted2 = f_Tau_xy_vec_sorted(I2);
f_Press_vec_sorted2 = f_Press_vec_sorted(I2);
f_Mrho_vec_sorted2 = f_Mrho_vec_sorted(I2);
f_Ttra_vec_sorted2 = f_Ttra_vec_sorted(I2);

Center_Positions_BM = zeros(2,N,N);
Velocity_BM = zeros(2,N,N);
Tauxx_BM = zeros(N,N);
Tauyy_BM = zeros(N,N);
Tauxy_BM = zeros(N,N);
Pressure_BM = zeros(N,N);
Density_BM = zeros(N,N);
Temp_BM = zeros(N,N);

for II = 1:N
for JJ = 1:N
    index = II + (JJ-1)*N;
    Center_Positions_BM(:,II,JJ) = [xc_vec_sorted2(index) yc_vec_sorted2(index)]';
    Velocity_BM(:,II,JJ) = [f_U_vec_sorted2(index) f_V_vec_sorted2(index)]';
    Tauxx_BM(II,JJ) = f_Tau_xx_vec_sorted2(index);
    Tauyy_BM(II,JJ) = f_Tau_yy_vec_sorted2(index);
    Tauxy_BM(II,JJ) = f_Tau_xy_vec_sorted2(index);
    Pressure_BM(II,JJ) = f_Press_vec_sorted2(index);
    Density_BM(II,JJ) = f_Mrho_vec_sorted2(index);
    Temp_BM(II,JJ) = f_Ttra_vec_sorted2(index);
end
end

x(1:N,1) = Center_Positions_BM(1,1:N,1);
y(1:N,1) = Center_Positions_BM(2,1,1:N);

[X,Y] = meshgrid(x,y);

U_DSMC(1:N,1:N) = Velocity_BM(1,1:N,1:N);
V_DSMC(1:N,1:N) = Velocity_BM(2,1:N,1:N);
p_DSMC = Pressure_BM(1:N,1:N);
tau_xx_DSMC = Tauxx_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
tau_yy_DSMC = Tauyy_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
tau_xy_DSMC = Tauxy_BM(1:N,1:N);

if (Kn == 0.05)
    density = 0.0000017164;
    pressure = density*208*273;
elseif (Kn == 0.5)
    density = 0.00000017164;
    pressure = density*208*273;
elseif (Kn == 5)
    density = 0.000000017164;
    pressure = density*208*273;
end

%% Benchmark Data %%

datastart = 801000;
interval = 300000;

filename = sprintf(['../../../../DSMC/Kn_0_5_M_0_1/prop_grid.%d.dat'], datastart+interval);
    
fileID = fopen(filename);
for k=1:9
    fgets(fileID);
end
C = textscan(fileID,'%f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64');
fclose(fileID);

xc_vec = C{1}';
yc_vec = C{2}';
f_U_vec = C{3}';
f_V_vec = C{4}';
f_Tau_xx_vec = C{5}';
f_Tau_yy_vec = C{6}';
f_Tau_xy_vec = C{7}';
f_Press_vec = C{8}';
f_Mrho_vec = C{9}';
f_Ttra_vec = C{10}';

%First sorting by x:
[xc_vec_sorted,I] = sort(xc_vec);
yc_vec_sorted = yc_vec(I);
f_U_vec_sorted = f_U_vec(I);
f_V_vec_sorted = f_V_vec(I);
f_Tau_xx_vec_sorted = f_Tau_xx_vec(I);
f_Tau_yy_vec_sorted = f_Tau_yy_vec(I);
f_Tau_xy_vec_sorted = f_Tau_xy_vec(I);
f_Press_vec_sorted = f_Press_vec(I);
f_Mrho_vec_sorted = f_Mrho_vec(I);
f_Ttra_vec_sorted = f_Ttra_vec(I);

%Second sorting by y:
[yc_vec_sorted2,I2] = sort(yc_vec_sorted);
xc_vec_sorted2 = xc_vec_sorted(I2);
f_U_vec_sorted2 = f_U_vec_sorted(I2);
f_V_vec_sorted2 = f_V_vec_sorted(I2);
f_Tau_xx_vec_sorted2 = f_Tau_xx_vec_sorted(I2);
f_Tau_yy_vec_sorted2 = f_Tau_yy_vec_sorted(I2);
f_Tau_xy_vec_sorted2 = f_Tau_xy_vec_sorted(I2);
f_Press_vec_sorted2 = f_Press_vec_sorted(I2);
f_Mrho_vec_sorted2 = f_Mrho_vec_sorted(I2);
f_Ttra_vec_sorted2 = f_Ttra_vec_sorted(I2);

Center_Positions_BM = zeros(2,N,N);
Velocity_BM = zeros(2,N,N);
Tauxx_BM = zeros(N,N);
Tauyy_BM = zeros(N,N);
Tauxy_BM = zeros(N,N);
Pressure_BM = zeros(N,N);
Density_BM = zeros(N,N);
Temp_BM = zeros(N,N);

for II = 1:N
for JJ = 1:N
    index = II + (JJ-1)*N;
    Center_Positions_BM(:,II,JJ) = [xc_vec_sorted2(index) yc_vec_sorted2(index)]';
    Velocity_BM(:,II,JJ) = [f_U_vec_sorted2(index) f_V_vec_sorted2(index)]';
    Tauxx_BM(II,JJ) = f_Tau_xx_vec_sorted2(index);
    Tauyy_BM(II,JJ) = f_Tau_yy_vec_sorted2(index);
    Tauxy_BM(II,JJ) = f_Tau_xy_vec_sorted2(index);
    Pressure_BM(II,JJ) = f_Press_vec_sorted2(index);
    Density_BM(II,JJ) = f_Mrho_vec_sorted2(index);
    Temp_BM(II,JJ) = f_Ttra_vec_sorted2(index);
end
end

x(1:N,1) = Center_Positions_BM(1,1:N,1);
y(1:N,1) = Center_Positions_BM(2,1,1:N);


U_BM_DSMC(1:N,1:N) = Velocity_BM(1,1:N,1:N);
V_BM_DSMC(1:N,1:N) = Velocity_BM(2,1:N,1:N);
p_BM_DSMC = Pressure_BM(1:N,1:N);
tau_xx_BM_DSMC = Tauxx_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
tau_yy_BM_DSMC = Tauyy_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
tau_xy_BM_DSMC = Tauxy_BM(1:N,1:N);

%% Fits %%

%% Tau %%

%Velocity%
nn = 0;
filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Interior_Data_nsample_%d.dat'],nn);
fileID = fopen(filename,'r');
formatSpec = '%g %g';
sizeInteriorVelocityData = [2 (N*N)];
Velocity_Interior_Data = fscanf(fileID,formatSpec,sizeInteriorVelocityData);
fclose(fileID);
Velocity_Interior_Data = Velocity_Interior_Data';

U_fit = zeros(N,N);
V_fit = zeros(N,N);
for JJ = 1:1:N
for II = 1:1:N
index = II + (JJ-1)*N;
U_fit(II,JJ) = Velocity_Interior_Data(index,1);
V_fit(II,JJ) = Velocity_Interior_Data(index,2);
end
end


%Pressure%
nn = 0;
filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Interior_Data_nsample_%d.dat'],nn);
fileID = fopen(filename,'r');
formatSpec = '%g';
sizeInteriorPressureData = [1 (N*N)];
Pressure_Interior_Data = fscanf(fileID,formatSpec,sizeInteriorPressureData);
fclose(fileID);
Pressure_Interior_Data = Pressure_Interior_Data';

p_fit = zeros(N,N);
for JJ = 1:1:N
for II = 1:1:N
index = II + (JJ-1)*N;
p_fit(II,JJ) = Pressure_Interior_Data(index,1);
end
end

%Stress corrections tensor%
nn = 0;
filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_%d_2.dat'],nn);
fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g %g %g %g';
sizeInteriorStressData = [7 (N*N)];
Stress_Interior_Data = fscanf(fileID,formatSpec,sizeInteriorStressData);
fclose(fileID);

Stress_Interior_Data = Stress_Interior_Data';
tauxxCorr_2 = Stress_Interior_Data(:,1);
epsilonxxCorr_2 = Stress_Interior_Data(:,2);
tauyyCorr_2 = Stress_Interior_Data(:,3);
epsilonyyCorr_2 = Stress_Interior_Data(:,4);
tauxyCorr_2 = Stress_Interior_Data(:,5);
epsilonxyCorr_2 = Stress_Interior_Data(:,6);
epsilonyxCorr_2 = Stress_Interior_Data(:,7);

tau_xx_fit = zeros(N,N);
tau_yy_fit = zeros(N,N);
tau_xy_fit = zeros(N,N);
phixy = zeros(N,N);

for JJ = 1:1:N
for II = 1:1:N
index = II + (JJ-1)*N;
tau_xx_fit(II,JJ) = tauxxCorr_2(index,1);
tau_yy_fit(II,JJ) = tauyyCorr_2(index,1);
tau_xy_fit(II,JJ) = tauxyCorr_2(index,1);
end
end

%% CFD Samples %%

filename_muE = sprintf(['muE_Minimisation_10_Percent_AR_1_Kn_0_5_M_0_1.txt']);
fileID_muE = fopen(filename_muE,'r');
muE_factor_vec = fscanf(fileID_muE,'%g');
fclose(fileID_muE);

N = 50;
nsample = 50;
%nsample = 5;
nsample = nsample + 1;

U_CFD_Mat = zeros(N,N,nsample);
V_CFD_Mat = zeros(N,N,nsample);
p_CFD_Mat = zeros(N,N,nsample);
tau_xx_CFD_Mat = zeros(N,N,nsample);
tau_yy_CFD_Mat = zeros(N,N,nsample);
tau_xy_CFD_Mat = zeros(N,N,nsample);

for nn = 1:1:nsample

filename_U = sprintf(['6_nsample_%d/U'],nn-1);
fileID = fopen(filename_U, 'r');
for i = 1:21
    fgets(fileID);
end
fileContent = fscanf(fileID, '(%g %g %g)\n', [3 N*N]);
vx = fileContent(1,:);
vy = fileContent(2,:);
vz = fileContent(3,:);
fclose(fileID);

filenamep = sprintf(['6_nsample_%d/p'],nn-1);
fileIDp = fopen(filenamep, 'r');
for i = 1:21
    fgets(fileIDp);
end
Press = fscanf(fileIDp, '%g\n', [1 N*N]);
fclose(fileIDp);

filenametau = sprintf(['6_nsample_%d/Stress_Corrections_Tensor'],nn-1);
fileIDtau = fopen(filenametau, 'r');
for i = 1:21
    fgets(fileIDtau);
end
fileContenttau = fscanf(fileIDtau, '(%g %g %g %g %g %g %g %g %g)\n', [9 N*N]);
Tauxxc = fileContenttau(1,:);
Tauxyc = fileContenttau(2,:);
Tauyyc = fileContenttau(5,:);
fclose(fileIDtau);

ii = 0;
for i = 1:N
    for j = 1:N
        ii = ii + 1;
        u(i,j) = vx(ii);
        v(i,j) = vy(ii);
        tauxxc(i,j) = Tauxxc(ii)*density;
        tauxyc(i,j) = Tauxyc(ii)*density;
        tauyyc(i,j) = Tauyyc(ii)*density;
        %p(i,j) = (Press(ii)*density) + pressure;
        p(i,j) = (Press(ii)*density);
       
    end
end

U_CFD_Mat(1:N,1:N,nn) = u';
V_CFD_Mat(1:N,1:N,nn) = v';
p_CFD_Mat(1:N,1:N,nn) = p';

h = 1;
dy = h/N;
x(1) = -h*0.5+dy/2;
y(1) = -h*0.5 + dy/2;
for i = 2:N
    x(i) = x(i-1) + dy;
    y(i) = y(i-1) + dy;
end

[X,Y] = meshgrid(x,y);
muE = 2.117e-5;
muE = muE*muE_factor_vec(nn,1);

for i = 2:N-1
    for j = 2:N-1
        % Calculate strain rate components
        dudx(i,j) = (u(i,j+1) - u(i,j-1)) / (X(i,j+1) - X(i,j-1));
        dvdy(i,j) = (v(i+1,j) - v(i-1,j)) / (Y(i+1,j) - Y(i-1,j));
        dudy(i,j) = (u(i+1,j) - u(i-1,j)) / (Y(i+1,j) - Y(i-1,j));
        dvdx(i,j) = (v(i,j+1) - v(i,j-1)) / (X(i,j+1) - X(i,j-1));
    end
end

dx = dy;
for i = 2:(N-1)
dudx(i,1) = (-3*u(i,1) + 4*u(i,2) - u(i,3))/(2*dx);  %% left
dudx(i,N) = (3*u(i,N) - 4*u(i,N-1) + u(i,N-2))/(2*dx); %% right
dvdy(i,1) = (v(i+1,1) - v(i-1,1))/(2*dy);
dvdy(i,N) = (v(i+1,N) - v(i-1,N))/(2*dy);
dudy(i,1) = (u(i+1,1) - u(i-1,1))/(2*dy);
dudy(i,N) = (u(i+1,N) - u(i-1,N))/(2*dy);
dvdx(i,1) = (-3*v(i,1) + 4*v(i,2) - v(i,3))/(2*dx);
dvdx(i,N) = (3*v(i,N) - 4*v(i,N-1) + v(i,N-2))/(2*dx);
end

for j = 2:(N-1)
dudx(1,j) = (u(1,j+1) - u(1,j-1))/(2*dx); %bottom
dudx(N,j) = (u(N,j+1) - u(N,j-1))/(2*dx); % top
dvdy(1,j) = (-3*v(1,j) + 4*v(2,j) - v(3,j))/(2*dy);
dvdy(N,j) = (3*v(N,j) - 4*v(N-1,j) + v(N-2,j))/(2*dy);
dudy(1,j) = (-3*u(1,j) + 4*u(2,j) - u(3,j))/(2*dy);
dudy(N,j) = (3*u(N,j) - 4*u(N-1,j) + u(N-2,j))/(2*dy);
dvdx(1,j) = (v(1,j+1) - v(1,j-1))/(2*dx);
dvdx(N,j) = (v(N,j+1) - v(N,j-1))/(2*dx);
end

dudx(1,1) = (-3*u(1,1) + 4*u(1,2) - u(1,3))/(2*dx);
dvdy(1,1) = (-3*v(1,1) + 4*v(2,1) - v(3,1))/(2*dy);
dudy(1,1) = (-3*u(1,1) + 4*u(2,1) - u(3,1))/(2*dy);
dvdx(1,1) = (-3*v(1,1) + 4*v(1,2) - v(1,3))/(2*dx);

dudx(1,N) = (3*u(1,N) - 4*u(1,N-1) + u(1,N-2))/(2*dx);
dvdy(1,N) = (-3*v(1,N) + 4*v(2,N) - v(3,N))/(2*dy);
dudy(1,N) = (-3*u(1,N) + 4*u(2,N) - u(3,N))/(2*dy);
dvdx(1,N) = (3*v(1,N) - 4*v(1,N-1) + v(1,N-2))/(2*dx);

dudx(N,1) = (-3*v(N,1) + 4*v(N,2) - v(N,3))/(2*dx);
dvdy(N,1) = (3*v(N,1) - 4*v(N-1,1) + v(N-2,1))/(2*dy);
dudy(N,1) = (3*u(N,1) - 4*u(N-1,1) + u(N-2,1))/(2*dy);
dvdx(N,1) = (-3*v(N,1) + 4*v(N,2) - v(N,3))/(2*dx);

dudx(N,N) = (3*u(N,N) - 4*u(N,N-1) + u(N,N-2))/(2*dx);
dvdy(N,N) = (3*v(N,N) - 4*v(N-1,N) + v(N-2,N))/(2*dy);
dudy(N,N) = (3*u(N,N) - 4*u(N-1,N) + u(N-2,N))/(2*dy);
dvdx(N,N) = (3*v(N,N) - 4*v(N,N-1) + v(N,N-1))/(2*dx);

for i = 1:N
    for j = 1:N
        tau_xx(i,j) = -2*muE*dudx(i,j) + tauxxc(i,j) ;
        tau_xy(i,j) = -muE*(dudy(i,j) + dvdx(i,j)) + tauxyc(i,j);
        tau_yy(i,j) = -2*muE*dvdy(i,j) + tauyyc(i,j);
    end 
end

tau_xx_CFD_Mat(1:N,1:N,nn) = tau_xx';
tau_yy_CFD_Mat(1:N,1:N,nn) = tau_yy';
tau_xy_CFD_Mat(1:N,1:N,nn) = tau_xy';

end

%% 95% Confidence Intervals %%

%U:

U_CFD_Upper = zeros(N1,N2);
U_CFD_Lower = zeros(N1,N2);
percent = 2.5;

U_CFD_Mean(1:N,1:N) = U_CFD_Mat(1:N,1:N,1);
%U_CFD_Mean(1:N,1:N) = mean(U_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

U_CFD_1D(1:nsample-1,1) = U_CFD_Mat(II,JJ,2:nsample);    
U_CFD_Upper(II,JJ) = prctile(U_CFD_1D,100-percent);
U_CFD_Lower(II,JJ) = prctile(U_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,U_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,U_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,U_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis equal;
axis tight;

figure;
hold on;
plot(x,U_DSMC(1:N,end));
hold on;
plot(x,U_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [U_CFD_Lower(1:N,end)' fliplr(U_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
hold on;
plot(x,U_BM_DSMC(1:N,end));
xlabel('x');
ylabel('U(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,U_DSMC(1:N,26));
hold on;
plot(x,U_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [U_CFD_Lower(1:N,26)' fliplr(U_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,U_BM_DSMC(1:N,26));
xlabel('x');
ylabel('U(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,U_DSMC(26,1:N));
hold on;
plot(x,U_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [U_CFD_Lower(26,1:N) fliplr(U_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,U_BM_DSMC(26,1:N));
xlabel('x');
ylabel('U(x=0)');
axis square;
axis tight;

%V:

V_CFD_Upper = zeros(N1,N2);
V_CFD_Lower = zeros(N1,N2);
percent = 2.5;

V_CFD_Mean(1:N,1:N) = V_CFD_Mat(1:N,1:N,1);
%V_CFD_Mean(1:N,1:N) = mean(V_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

V_CFD_1D(1:nsample-1,1) = V_CFD_Mat(II,JJ,2:nsample);    
V_CFD_Upper(II,JJ) = prctile(V_CFD_1D,100-percent);
V_CFD_Lower(II,JJ) = prctile(V_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,V_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,V_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,V_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V';
axis equal;
axis tight;

figure;
hold on;
plot(x,V_DSMC(1:N,end));
hold on;
plot(x,V_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [V_CFD_Lower(1:N,end)' fliplr(V_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
hold on;
plot(x,V_BM_DSMC(1:N,end));
xlabel('x');
ylabel('V(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,V_DSMC(1:N,26));
hold on;
plot(x,V_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [V_CFD_Lower(1:N,26)' fliplr(V_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,V_BM_DSMC(1:N,26));
xlabel('x');
ylabel('V(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,V_DSMC(26,1:N));
hold on;
plot(x,V_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [V_CFD_Lower(26,1:N) fliplr(V_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,V_BM_DSMC(26,1:N));
xlabel('x');
ylabel('V(x=0)');
axis square;
axis tight;

%p:

p_CFD_Upper = zeros(N1,N2);
p_CFD_Lower = zeros(N1,N2);
percent = 2.5;

p_CFD_Mean(1:N,1:N) = p_CFD_Mat(1:N,1:N,1);
%p_CFD_Mean(1:N,1:N) = mean(p_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

p_CFD_1D(1:nsample-1,1) = p_CFD_Mat(II,JJ,2:nsample);    
p_CFD_Upper(II,JJ) = prctile(p_CFD_1D,100-percent);
p_CFD_Lower(II,JJ) = prctile(p_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,p_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,p_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,p_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis equal;
axis tight;

figure;
hold on;
plot(x,p_DSMC(1:N,end));
hold on;
plot(x,p_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [p_CFD_Lower(1:N,end)' fliplr(p_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,p_BM_DSMC(1:N,end));
xlabel('x');
ylabel('p(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,p_DSMC(1:N,26));
hold on;
plot(x,p_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [p_CFD_Lower(1:N,26)' fliplr(p_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,p_BM_DSMC(1:N,26));
xlabel('x');
ylabel('p(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,p_DSMC(26,1:N));
hold on;
plot(x,p_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [p_CFD_Lower(26,1:N) fliplr(p_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,p_BM_DSMC(26,1:N));
xlabel('x');
ylabel('p(x=0)');
axis square;
axis tight;

%tau_xx:

tau_xx_CFD_Upper = zeros(N1,N2);
tau_xx_CFD_Lower = zeros(N1,N2);
percent = 2.5;

tau_xx_CFD_Mean(1:N,1:N) = tau_xx_CFD_Mat(1:N,1:N,1);
%tau_xx_CFD_Mean(1:N,1:N) = mean(tau_xx_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

tau_xx_CFD_1D(1:nsample-1,1) = tau_xx_CFD_Mat(II,JJ,2:nsample);    
tau_xx_CFD_Upper(II,JJ) = prctile(tau_xx_CFD_1D,100-percent);
tau_xx_CFD_Lower(II,JJ) = prctile(tau_xx_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xx_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xx';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xx_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xx';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xx_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xx';
axis equal;
axis tight;

figure;
hold on;
plot(x,tau_xx_DSMC(1:N,end));
hold on;
plot(x,tau_xx_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xx_CFD_Lower(1:N,end)' fliplr(tau_xx_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xx_BM_DSMC(1:N,end));
xlabel('x');
ylabel('tau_xx(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_xx_DSMC(1:N,26));
hold on;
plot(x,tau_xx_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xx_CFD_Lower(1:N,26)' fliplr(tau_xx_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xx_BM_DSMC(1:N,26));
xlabel('x');
ylabel('tau_xx(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_xx_DSMC(26,1:N));
hold on;
plot(x,tau_xx_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xx_CFD_Lower(26,1:N) fliplr(tau_xx_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xx_BM_DSMC(26,1:N));
xlabel('x');
ylabel('tau_xx(x=0)');
axis square;
axis tight;

%tau_yy:

tau_yy_CFD_Upper = zeros(N1,N2);
tau_yy_CFD_Lower = zeros(N1,N2);
percent = 2.5;

tau_yy_CFD_Mean(1:N,1:N) = tau_yy_CFD_Mat(1:N,1:N,1);
%tau_yy_CFD_Mean(1:N,1:N) = mean(tau_yy_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

tau_yy_CFD_1D(1:nsample-1,1) = tau_yy_CFD_Mat(II,JJ,2:nsample);    
tau_yy_CFD_Upper(II,JJ) = prctile(tau_yy_CFD_1D,100-percent);
tau_yy_CFD_Lower(II,JJ) = prctile(tau_yy_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_yy_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_yy';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_yy_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_yy';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_yy_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_yy';
axis equal;
axis tight;

figure;
hold on;
plot(x,tau_yy_DSMC(1:N,end));
hold on;
plot(x,tau_yy_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_yy_CFD_Lower(1:N,end)' fliplr(tau_yy_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_yy_BM_DSMC(1:N,end));
xlabel('x');
ylabel('tau_yy(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_yy_DSMC(1:N,26));
hold on;
plot(x,tau_yy_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_yy_CFD_Lower(1:N,26)' fliplr(tau_yy_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_yy_BM_DSMC(1:N,26));
xlabel('x');
ylabel('tau_yy(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_yy_DSMC(26,1:N));
hold on;
plot(x,tau_yy_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_yy_CFD_Lower(26,1:N) fliplr(tau_yy_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_yy_BM_DSMC(26,1:N));
xlabel('x');
ylabel('tau_yy(x=0)');
axis square;
axis tight;

%tau_xy:

tau_xy_CFD_Upper = zeros(N1,N2);
tau_xy_CFD_Lower = zeros(N1,N2);
percent = 2.5;

tau_xy_CFD_Mean(1:N,1:N) = tau_xy_CFD_Mat(1:N,1:N,1);
%tau_xy_CFD_Mean(1:N,1:N) = mean(tau_xy_CFD_Mat(1:N,1:N,2:nsample),3);

for JJ = 1:N2
for II = 1:N1

tau_xy_CFD_1D(1:nsample-1,1) = tau_xy_CFD_Mat(II,JJ,2:nsample);    
tau_xy_CFD_Upper(II,JJ) = prctile(tau_xy_CFD_1D,100-percent);
tau_xy_CFD_Lower(II,JJ) = prctile(tau_xy_CFD_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xy_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xy';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xy_BM_DSMC');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xy';
axis equal;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
hold on;
contourf(X,Y,tau_xy_CFD_Mean');
hold on;
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tau\_xy';
axis equal;
axis tight;

figure;
hold on;
plot(x,tau_xy_DSMC(1:N,end));
hold on;
plot(x,tau_xy_CFD_Mean(1:N,end),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xy_CFD_Lower(1:N,end)' fliplr(tau_xy_CFD_Upper(1:N,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xy_BM_DSMC(1:N,end));
xlabel('x');
ylabel('tau_xy(y=1)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_xy_DSMC(1:N,26));
hold on;
plot(x,tau_xy_CFD_Mean(1:N,26),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xy_CFD_Lower(1:N,26)' fliplr(tau_xy_CFD_Upper(1:N,26)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xy_BM_DSMC(1:N,26));
xlabel('x');
ylabel('tau_xy(y=0)');
axis square;
axis tight;

figure;
hold on;
plot(x,tau_xy_DSMC(26,1:N));
hold on;
plot(x,tau_xy_CFD_Mean(26,1:N),'g--');
hold on;
hold on;
fill([x' fliplr(x')], [tau_xy_CFD_Lower(26,1:N) fliplr(tau_xy_CFD_Upper(26,1:N))],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
plot(x,tau_xy_BM_DSMC(26,1:N));
xlabel('x');
ylabel('tau_xy(x=0)');
axis square;
axis tight;
