
clear all;
close all;

N1 = 100;
N2 = 50;

nsample = 50;

for nn = 0:1:nsample

%filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Approx_Boundary_Data_Left_Right_nsample_%d_2.dat'],nn);
filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Exact_Boundary_Data_Left_Right_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g';
sizeBoundaryData = [4 N2];
Velocity_Boundary_Data = fscanf(fileID,formatSpec,sizeBoundaryData);
fclose(fileID);

Velocity_Boundary_Data = Velocity_Boundary_Data';
U_left = Velocity_Boundary_Data(:,1);
V_left = Velocity_Boundary_Data(:,2);
U_right = Velocity_Boundary_Data(:,3);
V_right = Velocity_Boundary_Data(:,4);

%filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Approx_Boundary_Data_Bottom_Top_nsample_%d_2.dat'],nn);
filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Exact_Boundary_Data_Bottom_Top_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g';
sizeBoundaryData = [4 N1];
Velocity_Boundary_Data = fscanf(fileID,formatSpec,sizeBoundaryData);
fclose(fileID);

Velocity_Boundary_Data = Velocity_Boundary_Data';
U_bottom = Velocity_Boundary_Data(:,1);
V_bottom = Velocity_Boundary_Data(:,2);
U_top = Velocity_Boundary_Data(:,3);
V_top = Velocity_Boundary_Data(:,4);

filename = sprintf(['0/boundaryCorrections_nsample_%d'],nn);
fileID = fopen(filename,'w');
fprintf(fileID,'velocityProfile\n');
fprintf(fileID,'List<vector>\n');
fprintf(fileID,'200\n');
fprintf(fileID,'(\n');

for i = 1:1:200

if ( (i >= 1) && (i <= 50) )

fprintf(fileID,'(%g %g %g)\n', U_left(i,1), V_left(i,1), 0.0);

elseif ( (i >= 51) && (i <= 100) )    

fprintf(fileID,'(%g %g %g)\n', U_right(i-50,1), V_right(i-50,1), 0.0);

elseif ( (i >= 101) && (i <= 200) )    

fprintf(fileID,'(%g %g %g)\n', U_bottom(i-100,1), V_bottom(i-100,1), 0.0);

end    

end

fprintf(fileID,');\n');

fprintf(fileID,'topProfile\n');
fprintf(fileID,'List<vector>\n');
fprintf(fileID,'100\n');
fprintf(fileID,'(\n');

for i = 1:1:100

fprintf(fileID,'(%f %f %f)\n', U_top(i,1), V_top(i,1), 0.0);

end

fprintf(fileID,');\n');

fclose(fileID);

end
