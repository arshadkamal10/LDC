
clear all;
close all;

%From SPARTA input script:
Temp = 273.15;
Dref = 4.17e-10;
Tref = 273.15;
omeg = 0.81;
numdensity = 2.5888e18;
mfp = ( (sqrt(2)*pi*((Dref)^2)*numdensity*(Tref/Temp)^(omeg-(1/2)))^(-1) );

%factor = (1/5);
%factor = 1;
factor = 2000;
%factor = 0.3;
%factor = 5;
Cutoff_Distance = factor*mfp;

h1 = 2;
h2 = 1;

N1 = 100;
N2 = 50;

%%  Steps: %%

Nsample = 50;

%% (1) Initialise text file containing muE factors

filename_muE = sprintf(['muE_Minimisation_10_Percent_AR_0_5_Kn_0_5_M_0_2.txt']);
fileID_muE = fopen(filename_muE,'w');

%% (2) Go through file by file and compute factors

for np = 1:1:(Nsample + 1)

filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_%d_2.dat'],np-1);
%filename = sprintf(['10_Percent_WholeDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_%d_2.dat'],np-1);
fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g %g %g %g';
sizeInteriorStressData = [7 (N1*N2)];
Stress_Interior_Data = fscanf(fileID,formatSpec,sizeInteriorStressData);
fclose(fileID);

Stress_Interior_Data = Stress_Interior_Data';
tauxxCorr = Stress_Interior_Data(:,1);
epsilonxxCorr = Stress_Interior_Data(:,2);
tauyyCorr = Stress_Interior_Data(:,3);
epsilonyyCorr = Stress_Interior_Data(:,4);
tauxyCorr = Stress_Interior_Data(:,5);
epsilonxyCorr = Stress_Interior_Data(:,6);
epsilonyxCorr = Stress_Interior_Data(:,7);

dx = h1/N1;
x = [((-h1/2)+(dx/2)):dx:((h1/2)-(dx/2))]';

dy = h2/N2;
y = [((-h2/2)+(dy/2)):dy:((h2/2)-(dy/2))]';

tauxxCorr_2 = zeros(N1,N2);
epsilonxxCorr_2 = zeros(N1,N2);
tauyyCorr_2 = zeros(N1,N2);
epsilonyyCorr_2 = zeros(N1,N2);
tauxyCorr_2 = zeros(N1,N2);
epsilonxyCorr_2 = zeros(N1,N2);
epsilonyxCorr_2 = zeros(N1,N2);

for JJ = 1:1:N2
y_grid = y(JJ,1);    
for II = 1:1:N1
x_grid = x(II,1);

index = II + (JJ - 1)*N1;
tauxxCorr_2(II,JJ) = tauxxCorr(index,1);
epsilonxxCorr_2(II,JJ) = epsilonxxCorr(index,1);
tauyyCorr_2(II,JJ) = tauyyCorr(index,1);
epsilonyyCorr_2(II,JJ) = epsilonyyCorr(index,1);
tauxyCorr_2(II,JJ) = tauxyCorr(index,1);
epsilonxyCorr_2(II,JJ) = epsilonxyCorr(index,1);
epsilonyxCorr_2(II,JJ) = epsilonyxCorr(index,1);

end
end

tauxxCorr_2(isnan(tauxxCorr_2))=0;
epsilonxxCorr_2(isnan(epsilonxxCorr_2))=0;
tauyyCorr_2(isnan(tauyyCorr_2))=0;
epsilonyyCorr_2(isnan(epsilonyyCorr_2))=0;
tauxyCorr_2(isnan(tauxyCorr_2))=0;
epsilonxyCorr_2(isnan(epsilonxyCorr_2))=0;
epsilonyxCorr_2(isnan(epsilonyxCorr_2))=0;

x1 = x';
y1 = y';
[X1,Y1] = meshgrid(x1,y1);

muE_0 = 2.117e-5;

%muE_xx
tau_xx_1 = tauxxCorr_2;
epsilon_xx_1 = epsilonxxCorr_2;
tau_xx_epsilon_xx_1 = tau_xx_1.*epsilon_xx_1;
epsilon_xx_sq_1 = epsilon_xx_1.*epsilon_xx_1;

%muEyy:
tau_yy_1 = tauyyCorr_2;
epsilon_yy_1 = epsilonyyCorr_2;
tau_yy_epsilon_yy_1 = tau_yy_1.*epsilon_yy_1;
epsilon_yy_sq_1 = epsilon_yy_1.*epsilon_yy_1;

%muExy:
tau_xy_1 = tauxyCorr_2;
epsilon_xy_1 = epsilonxyCorr_2 + epsilonyxCorr_2;
tau_xy_epsilon_xy_1 = tau_xy_1.*epsilon_xy_1;
epsilon_xy_sq_1 = epsilon_xy_1.*epsilon_xy_1;

%matrix-2-norm
Numerator_new = ( (4*tau_xx_1.*epsilon_xx_1) + (4*tau_yy_1.*epsilon_yy_1) + (4*tau_yy_1.*( epsilon_xy_1  )) );
Denominator_new = ( (8*epsilon_xx_1.^2) + (8*epsilon_yy_1.^2) + 4*((epsilon_xy_1 ).^2) );
%Numerator_new_trapz = -trapz(y1,trapz(x1,Numerator_new,2));
Numerator_new_trapz = -trapz(y1,trapz(x1,Numerator_new,1));
%Denominator_new_trapz = trapz(y1,trapz(x1,Denominator_new,2));
Denominator_new_trapz = trapz(y1,trapz(x1,Denominator_new,1));
muE_new = Numerator_new_trapz/Denominator_new_trapz;
muE_new_scaled = muE_new/muE_0

%% (3) Write line by line the factors to text file

fprintf(fileID_muE,'%g\n', muE_new_scaled);

end

%% (5) Use Bash script to modify transportProperties file according to simulation
%%  number and factor