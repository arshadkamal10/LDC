#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#SBATCH --mem-per-cpu=3700
#SBATCH --time=48:00:00

module purge
module load GCC/11.2.0
module load OpenMPI/4.1.1
module load OpenFOAM/9
source $FOAM_BASH

cd ..
 
cd IcoFoam_AR_2_Kn_0_5_M_0_2

wmake

cd ..

cd LDC_icoFoam_AR_2_Kn_0_5_M_0_2_10Percent

blockMesh
checkMesh

i=0

file=muE_Minimisation_10_Percent_AR_2_Kn_0_5_M_0_2.txt

IFS=$'\n'
for line in $(cat "$file")
do

    echo -e "$line\n"

    echo "Starting simulation $i"  

    lineNo1=20
    sed -i "${lineNo1}s/.*/#include "\"boundaryCorrections_nsample_$i\"";/" 0/U  

    lineNo2=20
    sed -i "${lineNo2}s/.*/#include "\"pressureCorrections_nsample_$i\"";/" 0/p

    lineNo3=18
    sed -i "${lineNo3}s/.*/#include "\"stressCorrections_nsample_$i\"";/" 0/Stress_Corrections_Tensor
    
    lineNo4=18
    sed -i "${lineNo4}s/.*/#include "\"stressCorrections_nsample_$i\"";/" 0/Stress_Corrections_Tensor_Visualisation
    
    nu1=$(echo "123.341 * $line" | bc -l)
    echo "$nu1"
    
    lineNo5=17
    sed -i "${lineNo5}s/.*/nu                  [0 2 -1 0 0 0 0] $nu1;/" constant/transportProperties
    
    decomposePar
 
    mpirun IcoFoam_AR_2_Kn_0_5_M_0_2 -parallel #4x4 in decomposeParDict

    reconstructPar
    
    mv "6" "6_nsample_$i"

    rm -rf processor* 

    i=$((i+1))

done
