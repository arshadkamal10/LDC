
%tic

clear all;
close all;

Temp = 273.15;
Dref = 4.17e-10;
Tref = 273.15;
omeg = 0.81;
numdensity = 1.2944e19;
mfp = ( (sqrt(2)*pi*((Dref)^2)*numdensity*(Tref/Temp)^(omeg-(1/2)))^(-1) );

%factor = (1/5);
%factor = 1;
factor = 2;
%factor = 3;
Cutoff_Distance = factor*mfp;

Kn = 0.1;
h=1;       % channel height non-dim with mean free path (=1/Kn)
N=50; %500;      % number of bins (must be odd)

datastart = 800000;
%interval = 1500;
interval = 30000;

filename = sprintf(['../../../../DSMC/Kn_0_1_M_0_1/prop_grid.%d.dat'], datastart+interval);

fileID = fopen(filename);
for k=1:9
    fgets(fileID);
end
C = textscan(fileID,'%f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64 %f64');
fclose(fileID);

xc_vec = C{1}';
yc_vec = C{2}';
f_U_vec = C{3}';
f_V_vec = C{4}';
f_Tau_xx_vec = C{5}';
f_Tau_yy_vec = C{6}';
f_Tau_xy_vec = C{7}';
f_Press_vec = C{8}';
f_Mrho_vec = C{9}';
f_Ttra_vec = C{10}';

%First sorting by x:
[xc_vec_sorted,I] = sort(xc_vec);
yc_vec_sorted = yc_vec(I);
f_U_vec_sorted = f_U_vec(I);
f_V_vec_sorted = f_V_vec(I);
f_Tau_xx_vec_sorted = f_Tau_xx_vec(I);
f_Tau_yy_vec_sorted = f_Tau_yy_vec(I);
f_Tau_xy_vec_sorted = f_Tau_xy_vec(I);
f_Press_vec_sorted = f_Press_vec(I);
f_Mrho_vec_sorted = f_Mrho_vec(I);
f_Ttra_vec_sorted = f_Ttra_vec(I);

%Second sorting by y:
[yc_vec_sorted2,I2] = sort(yc_vec_sorted);
xc_vec_sorted2 = xc_vec_sorted(I2);
f_U_vec_sorted2 = f_U_vec_sorted(I2);
f_V_vec_sorted2 = f_V_vec_sorted(I2);
f_Tau_xx_vec_sorted2 = f_Tau_xx_vec_sorted(I2);
f_Tau_yy_vec_sorted2 = f_Tau_yy_vec_sorted(I2);
f_Tau_xy_vec_sorted2 = f_Tau_xy_vec_sorted(I2);
f_Press_vec_sorted2 = f_Press_vec_sorted(I2);
f_Mrho_vec_sorted2 = f_Mrho_vec_sorted(I2);
f_Ttra_vec_sorted2 = f_Ttra_vec_sorted(I2);

Center_Positions_BM = zeros(2,N,N);
Velocity_BM = zeros(2,N,N);
Tauxx_BM = zeros(N,N);
Tauyy_BM = zeros(N,N);
Tauxy_BM = zeros(N,N);
Pressure_BM = zeros(N,N);
Density_BM = zeros(N,N);
Temp_BM = zeros(N,N);

for II = 1:N
for JJ = 1:N
    index = II + (JJ-1)*N;
    Center_Positions_BM(:,II,JJ) = [xc_vec_sorted2(index) yc_vec_sorted2(index)]';
    Velocity_BM(:,II,JJ) = [f_U_vec_sorted2(index) f_V_vec_sorted2(index)]';
    Tauxx_BM(II,JJ) = f_Tau_xx_vec_sorted2(index);
    Tauyy_BM(II,JJ) = f_Tau_yy_vec_sorted2(index);
    Tauxy_BM(II,JJ) = f_Tau_xy_vec_sorted2(index);
    Pressure_BM(II,JJ) = f_Press_vec_sorted2(index);
    Density_BM(II,JJ) = f_Mrho_vec_sorted2(index);
    Temp_BM(II,JJ) = f_Ttra_vec_sorted2(index);
end
end

x(1:N,1) = Center_Positions_BM(1,1:N,1);
y(1:N,1) = Center_Positions_BM(2,1,1:N);

figure;
hold on;
U(1:N,1:N) = Velocity_BM(1,1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,U');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis square;
axis tight;

figure;
hold on;
V(1:N,1:N) = Velocity_BM(2,1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,V');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V';
axis square;
axis tight;

figure;
hold on;
p = Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,p');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis square;
axis tight;

figure;
hold on;
tauxx = Tauxx_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxx');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxx';
axis square;
axis tight;

figure;
hold on;
tauyy = Tauyy_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauyy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauyy';
axis square;
axis tight;

figure;
hold on;
tauxy = Tauxy_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxy';
axis square;
axis tight;

%% Subdomain Noisy DSMC %%

U_Cutoff = zeros(N,N);
V_Cutoff = zeros(N,N);
p_Cutoff = zeros(N,N);
tauxx_Cutoff = zeros(N,N);
tauyy_Cutoff = zeros(N,N);
tauxy_Cutoff = zeros(N,N);

for J = 1:N
for I = 1:N
    distance_x = abs(x(I,1));
    distance_y = abs(y(J,1));  
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )
    U_Cutoff(I,J) = U(I,J);
    V_Cutoff(I,J) = V(I,J);
    p_Cutoff(I,J) = p(I,J);
    tauxx_Cutoff(I,J) = tauxx(I,J);
    tauyy_Cutoff(I,J) = tauyy(I,J);
    tauxy_Cutoff(I,J) = tauxy(I,J);
    else
    U_Cutoff(I,J) = NaN;
    V_Cutoff(I,J) = NaN;
    p_Cutoff(I,J) = NaN;
    tauxx_Cutoff(I,J) = NaN;
    tauyy_Cutoff(I,J) = NaN;
    tauxy_Cutoff(I,J) = NaN;
    end
end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,U_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis square;
axis tight;

figure;
hold on;
V(1:N,1:N) = Velocity_BM(2,1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,V_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V';
axis square;
axis tight;

figure;
hold on;
p = Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,p_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis square;
axis tight;

figure;
hold on;
tauxx = Tauxx_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxx_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxx';
axis square;
axis tight;

figure;
hold on;
tauyy = Tauyy_BM(1:N,1:N) - Pressure_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauyy_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauyy';
axis square;
axis tight;

figure;
hold on;
tauxy = Tauxy_BM(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxy_Cutoff');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxy';
axis square;
axis tight;

%% (2) New: Levels for RBF centers and SDs %%

% (1) First try: Define levels with different SD for each level, but uniform flat
% hyperprior. Try this with Direct RVM and Sequential RVM.
% (2) Second try: Define levels with different SD and Gamma hyperprior for
% each level. Try this with Direct RVM first. 

%SD_dx_ratio = 16.2;
%SD_dx_ratio = 7.3;
%SD_dx_ratio = 3.1;
SD_dx_ratio = 1.8;
%SD_dx_ratio = 1.8;
%SD_dx_ratio = 1.8;

%Step 1: Define 3x3, 5x5, 9x9, 17x7, 33x33, 65x65 grids (uniformly spaced
%RBFs as before)

%3x3: Level 1
nmodel_level1 = 3;
Ci_level1 = zeros(nmodel_level1*nmodel_level1,2);
average_spacing_level1 = h/(nmodel_level1-1);

counter = 0;
for j = 1:(nmodel_level1)
counter = counter + 1;
Ci_level1(counter,1) = -0.5;
Ci_level1(counter,2) = -0.5 + ((j-1)*average_spacing_level1);
for i = 2:(nmodel_level1)
    counter = counter + 1;
    Ci_level1(counter,1) = Ci_level1(counter-1,1) + average_spacing_level1;
    Ci_level1(counter,2) = Ci_level1(counter-1,2);
end
end

sigmasq_level1 = (SD_dx_ratio*average_spacing_level1)*(SD_dx_ratio*average_spacing_level1);
var_rbf_level1 = (0.5/sigmasq_level1);

%5x5: Level 2
nmodel_level2 = 5;
Ci_level2 = zeros(nmodel_level2*nmodel_level2,2);
average_spacing_level2 = h/(nmodel_level2-1);

counter = 0;
for j = 1:(nmodel_level2)
counter = counter + 1;
Ci_level2(counter,1) = -0.5;
Ci_level2(counter,2) = -0.5 + ((j-1)*average_spacing_level2);
for i = 2:(nmodel_level2)
    counter = counter + 1;
    Ci_level2(counter,1) = Ci_level2(counter-1,1) + average_spacing_level2;
    Ci_level2(counter,2) = Ci_level2(counter-1,2);
end
end

sigmasq_level2 = (SD_dx_ratio*average_spacing_level2)*(SD_dx_ratio*average_spacing_level2);
var_rbf_level2 = (0.5/sigmasq_level2);

%9x9: Level 3
nmodel_level3 = 9;
Ci_level3 = zeros(nmodel_level3*nmodel_level3,2);
average_spacing_level3 = h/(nmodel_level3-1);

counter = 0;
for j = 1:(nmodel_level3)
counter = counter + 1;
Ci_level3(counter,1) = -0.5;
Ci_level3(counter,2) = -0.5 + ((j-1)*average_spacing_level3);
for i = 2:(nmodel_level3)
    counter = counter + 1;
    Ci_level3(counter,1) = Ci_level3(counter-1,1) + average_spacing_level3;
    Ci_level3(counter,2) = Ci_level3(counter-1,2);
end
end

sigmasq_level3 = (SD_dx_ratio*average_spacing_level3)*(SD_dx_ratio*average_spacing_level3);
var_rbf_level3 = (0.5/sigmasq_level3);

%17x17: Level 4
nmodel_level4 = 17;
Ci_level4 = zeros(nmodel_level4*nmodel_level4,2);
average_spacing_level4 = h/(nmodel_level4-1);

counter = 0;
for j = 1:(nmodel_level4)
counter = counter + 1;
Ci_level4(counter,1) = -0.5;
Ci_level4(counter,2) = -0.5 + ((j-1)*average_spacing_level4);
for i = 2:(nmodel_level4)
    counter = counter + 1;
    Ci_level4(counter,1) = Ci_level4(counter-1,1) + average_spacing_level4;
    Ci_level4(counter,2) = Ci_level4(counter-1,2);
end
end

sigmasq_level4 = (SD_dx_ratio*average_spacing_level4)*(SD_dx_ratio*average_spacing_level4);
var_rbf_level4 = (0.5/sigmasq_level4);

%{
%33x33: Level 5
nmodel_level5 = 33;
Ci_level5 = zeros(nmodel_level5*nmodel_level5,2);
average_spacing_level5 = h/(nmodel_level5-1);

counter = 0;
for j = 1:(nmodel_level5)
counter = counter + 1;
Ci_level5(counter,1) = -0.5;
Ci_level5(counter,2) = -0.5 + ((j-1)*average_spacing_level5);
for i = 2:(nmodel_level5)
    counter = counter + 1;
    Ci_level5(counter,1) = Ci_level5(counter-1,1) + average_spacing_level5;
    Ci_level5(counter,2) = Ci_level5(counter-1,2);
end
end

sigmasq_level5 = (SD_dx_ratio*average_spacing_level5)*(SD_dx_ratio*average_spacing_level5);
var_rbf_level5 = (0.5/sigmasq_level5);

%65x65: Level 6
nmodel_level6 = 65;
Ci_level6 = zeros(nmodel_level6*nmodel_level6,2);
average_spacing_level6 = h/(nmodel_level6-1);

counter = 0;
for j = 1:(nmodel_level6)
counter = counter + 1;
Ci_level6(counter,1) = -0.5;
Ci_level6(counter,2) = -0.5 + ((j-1)*average_spacing_level6);
for i = 2:(nmodel_level6)
    counter = counter + 1;
    Ci_level6(counter,1) = Ci_level6(counter-1,1) + average_spacing_level6;
    Ci_level6(counter,2) = Ci_level6(counter-1,2);
end
end

sigmasq_level6 = (SD_dx_ratio*average_spacing_level6)*(SD_dx_ratio*average_spacing_level6);
var_rbf_level6 = (0.5/sigmasq_level6);

%var_rbf_level1 = var_rbf_level6;
%var_rbf_level2 = var_rbf_level6;
%var_rbf_level3 = var_rbf_level6;
%var_rbf_level4 = var_rbf_level6;
%var_rbf_level5 = var_rbf_level6;
%}

%Step 2: Remove RBFs from each grid (no intersection) to create a set for
%each level

%Level 1:
Ci_level1_2 = Ci_level1;
NumRBFs_Level1 = size(Ci_level1_2,1);

%Level 2:
Ci_level2_2 = Ci_level2;
Deletion_Index_level2 = [];
counter = 0;
for j = 1:(nmodel_level2)
for i = 1:(nmodel_level2)
counter = counter + 1;

for counter1 = 1:NumRBFs_Level1
if ( (Ci_level2(counter,1) == Ci_level1_2(counter1,1)) && (Ci_level2(counter,2) == Ci_level1_2(counter1,2)) ) 
Deletion_Index_level2 = [Deletion_Index_level2 counter];
end
end
 
end
end

Ci_level2_2(Deletion_Index_level2,:) = [];
NumRBFs_Level2 = size(Ci_level2_2,1);

%Level 3:
Ci_level3_2 = Ci_level3;
Deletion_Index_level3 = [];
counter = 0;
for j = 1:(nmodel_level3)
for i = 1:(nmodel_level3)
counter = counter + 1;

for counter1 = 1:NumRBFs_Level1
if ( (Ci_level3(counter,1) == Ci_level1_2(counter1,1)) && (Ci_level3(counter,2) == Ci_level1_2(counter1,2)) ) 
Deletion_Index_level3 = [Deletion_Index_level3 counter];
end
end

for counter2 = 1:NumRBFs_Level2
if ( (Ci_level3(counter,1) == Ci_level2_2(counter2,1)) && (Ci_level3(counter,2) == Ci_level2_2(counter2,2)) ) 
Deletion_Index_level3 = [Deletion_Index_level3 counter];
end
end
 
end
end

Ci_level3_2(Deletion_Index_level3,:) = [];
NumRBFs_Level3 = size(Ci_level3_2,1);

%Level 4:
Ci_level4_2 = Ci_level4;
Deletion_Index_level4 = [];
counter = 0;
for j = 1:(nmodel_level4)
for i = 1:(nmodel_level4)
counter = counter + 1;

for counter1 = 1:NumRBFs_Level1
if ( (Ci_level4(counter,1) == Ci_level1_2(counter1,1)) && (Ci_level4(counter,2) == Ci_level1_2(counter1,2)) ) 
Deletion_Index_level4 = [Deletion_Index_level4 counter];
end
end

for counter2 = 1:NumRBFs_Level2
if ( (Ci_level4(counter,1) == Ci_level2_2(counter2,1)) && (Ci_level4(counter,2) == Ci_level2_2(counter2,2)) ) 
Deletion_Index_level4 = [Deletion_Index_level4 counter];
end
end

for counter3 = 1:NumRBFs_Level3
if ( (Ci_level4(counter,1) == Ci_level3_2(counter3,1)) && (Ci_level4(counter,2) == Ci_level3_2(counter3,2)) ) 
Deletion_Index_level4 = [Deletion_Index_level4 counter];
end
end
 
end
end

Ci_level4_2(Deletion_Index_level4,:) = [];
NumRBFs_Level4 = size(Ci_level4_2,1);

%{
%Level 5:
Ci_level5_2 = Ci_level5;
Deletion_Index_level5 = [];
counter = 0;
for j = 1:(nmodel_level5)
for i = 1:(nmodel_level5)
counter = counter + 1;

for counter1 = 1:NumRBFs_Level1
if ( (Ci_level5(counter,1) == Ci_level1_2(counter1,1)) && (Ci_level5(counter,2) == Ci_level1_2(counter1,2)) ) 
Deletion_Index_level5 = [Deletion_Index_level5 counter];
end
end

for counter2 = 1:NumRBFs_Level2
if ( (Ci_level5(counter,1) == Ci_level2_2(counter2,1)) && (Ci_level5(counter,2) == Ci_level2_2(counter2,2)) ) 
Deletion_Index_level5 = [Deletion_Index_level5 counter];
end
end

for counter3 = 1:NumRBFs_Level3
if ( (Ci_level5(counter,1) == Ci_level3_2(counter3,1)) && (Ci_level5(counter,2) == Ci_level3_2(counter3,2)) ) 
Deletion_Index_level5 = [Deletion_Index_level5 counter];
end
end

for counter4 = 1:NumRBFs_Level4
if ( (Ci_level5(counter,1) == Ci_level4_2(counter4,1)) && (Ci_level5(counter,2) == Ci_level4_2(counter4,2)) ) 
Deletion_Index_level5 = [Deletion_Index_level5 counter];
end
end
 
end
end

Ci_level5_2(Deletion_Index_level5,:) = [];
NumRBFs_Level5 = size(Ci_level5_2,1);

%Level 6:
Ci_level6_2 = Ci_level6;
Deletion_Index_level6 = [];
counter = 0;
for j = 1:(nmodel_level6)
for i = 1:(nmodel_level6)
counter = counter + 1;

for counter1 = 1:NumRBFs_Level1
if ( (Ci_level6(counter,1) == Ci_level1_2(counter1,1)) && (Ci_level6(counter,2) == Ci_level1_2(counter1,2)) ) 
Deletion_Index_level6 = [Deletion_Index_level6 counter];
end
end

for counter2 = 1:NumRBFs_Level2
if ( (Ci_level6(counter,1) == Ci_level2_2(counter2,1)) && (Ci_level6(counter,2) == Ci_level2_2(counter2,2)) ) 
Deletion_Index_level6 = [Deletion_Index_level6 counter];
end
end

for counter3 = 1:NumRBFs_Level3
if ( (Ci_level6(counter,1) == Ci_level3_2(counter3,1)) && (Ci_level6(counter,2) == Ci_level3_2(counter3,2)) ) 
Deletion_Index_level6 = [Deletion_Index_level6 counter];
end
end

for counter4 = 1:NumRBFs_Level4
if ( (Ci_level6(counter,1) == Ci_level4_2(counter4,1)) && (Ci_level6(counter,2) == Ci_level4_2(counter4,2)) ) 
Deletion_Index_level6 = [Deletion_Index_level6 counter];
end
end

for counter5 = 1:NumRBFs_Level5
if ( (Ci_level6(counter,1) == Ci_level5_2(counter5,1)) && (Ci_level6(counter,2) == Ci_level5_2(counter5,2)) ) 
Deletion_Index_level6 = [Deletion_Index_level6 counter];
end
end
 
end
end

Ci_level6_2(Deletion_Index_level6,:) = [];
NumRBFs_Level6 = size(Ci_level6_2,1);

%Plot of first four levels:

figure;
hold on;
scatter(Ci_level1_2(:,1),Ci_level1_2(:,2),'red','*');
hold on;
scatter(Ci_level2_2(:,1),Ci_level2_2(:,2),'blue','+');
hold on;
scatter(Ci_level3_2(:,1),Ci_level3_2(:,2),'yellow','square');
hold on;
scatter(Ci_level4_2(:,1),Ci_level4_2(:,2),'magenta','diamond');
%hold on;
%scatter(Ci_level5_2(:,1),Ci_level5_2(:,2),'cyan','<');
%hold on;
%scatter(Ci_level6_2(:,1),Ci_level6_2(:,2),'black','>');
xlabel('x');
ylabel('y');
axis square;
axis tight;
%}

%NumRBFs_Total = NumRBFs_Level1; 
%NumRBFs_Total = NumRBFs_Level1 + NumRBFs_Level2; 
%NumRBFs_Total = NumRBFs_Level1 + NumRBFs_Level2 + NumRBFs_Level3; 
NumRBFs_Total = NumRBFs_Level1 + NumRBFs_Level2 + NumRBFs_Level3 + NumRBFs_Level4; 
%NumRBFs_Total = NumRBFs_Level1 + NumRBFs_Level2 + NumRBFs_Level3 + NumRBFs_Level4 + NumRBFs_Level5; 
%NumRBFs_Total = NumRBFs_Level1 + NumRBFs_Level2 + NumRBFs_Level3 + NumRBFs_Level4 + NumRBFs_Level5 + NumRBFs_Level6; 

%% 3 models: %% 

tn_V_x = [];
tn_V_y = [];
tn_p = [];
tn_C_xx = [];
tn_C_yy = [];
tn_C_xy = [];
counter = 0;
for J = 1:N
for I = 1:N
    distance_x = abs(x(I,1));
    distance_y = abs(y(J,1));  
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;
    tn_V_x(counter,1) = U(I,J);
    tn_V_y(counter,1) = V(I,J);
    tn_p(counter,1) = p(I,J);
    tn_C_xx(counter,1) = tauxx(I,J);
    tn_C_yy(counter,1) = tauyy(I,J);
    tn_C_xy(counter,1) = tauxy(I,J);
    end
end
end

TargetSize_Training = size(tn_V_x,1);

%Phi_V_x = zeros(TargetSize_Training,NumRBFs_Total); 
%Phi_V_y = zeros(TargetSize_Training,NumRBFs_Total);
Phi_V_x = zeros(TargetSize_Training,1); 
Phi_V_y = zeros(TargetSize_Training,1);
Ci = [];
counter_data = 0;
for J = 1:N
y_grid = x(J,1);
for I = 1:N
x_grid = x(I,1);  

distance_x = abs(x_grid);
distance_y = abs(y_grid);    
if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

counter_data = counter_data + 1;

counter = 0;

%Level 1:
for counter1 = 1:NumRBFs_Level1
distance_x_RBF = abs(Ci_level1_2(counter1,1));
distance_y_RBF = abs(Ci_level1_2(counter1,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
counter = counter + 1;    
Ci(counter,1) = Ci_level1_2(counter1,1);
Ci(counter,2) = Ci_level1_2(counter1,2);
RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level1*RBF_y_level1;
Phi_V_y(counter_data,counter) = RBF_x_level1*RBF_y_level1;
end
end    

%Level 2:
for counter2 = 1:NumRBFs_Level2
distance_x_RBF = abs(Ci_level2_2(counter2,1));
distance_y_RBF = abs(Ci_level2_2(counter2,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
counter = counter + 1;    
Ci(counter,1) = Ci_level2_2(counter2,1);
Ci(counter,2) = Ci_level2_2(counter2,2);
RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level2*RBF_y_level2;
Phi_V_y(counter_data,counter) = RBF_x_level2*RBF_y_level2;
end
end  

%Level 3:
for counter3 = 1:NumRBFs_Level3
distance_x_RBF = abs(Ci_level3_2(counter3,1));
distance_y_RBF = abs(Ci_level3_2(counter3,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
counter = counter + 1;    
Ci(counter,1) = Ci_level3_2(counter3,1);
Ci(counter,2) = Ci_level3_2(counter3,2);
RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level3*RBF_y_level3;
Phi_V_y(counter_data,counter) = RBF_x_level3*RBF_y_level3;
end
end

%Level 4:
for counter4 = 1:NumRBFs_Level4
distance_x_RBF = abs(Ci_level4_2(counter4,1));
distance_y_RBF = abs(Ci_level4_2(counter4,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
counter = counter + 1;    
Ci(counter,1) = Ci_level4_2(counter4,1);
Ci(counter,2) = Ci_level4_2(counter4,2);
RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level4*RBF_y_level4;
Phi_V_y(counter_data,counter) = RBF_x_level4*RBF_y_level4;
end
end

%{
%Level 5:
for counter5 = 1:NumRBFs_Level5
distance_x_RBF = abs(Ci_level5_2(counter5,1));
distance_y_RBF = abs(Ci_level5_2(counter5,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
counter = counter + 1;    
Ci(counter,1) = Ci_level5_2(counter5,1);
Ci(counter,2) = Ci_level5_2(counter5,2);
RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level5*RBF_y_level5;
Phi_V_y(counter_data,counter) = RBF_x_level5*RBF_y_level5;
end
end

%Level 6:
for counter6 = 1:NumRBFs_Level6
distance_x_RBF = abs(Ci_level6_2(counter6,1));
distance_y_RBF = abs(Ci_level6_2(counter6,2));   
if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
counter = counter + 1;    
Ci(counter,1) = Ci_level6_2(counter6,1);
Ci(counter,2) = Ci_level6_2(counter6,2);
RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
Phi_V_x(counter_data,counter) = RBF_x_level6*RBF_y_level6;
Phi_V_y(counter_data,counter) = RBF_x_level6*RBF_y_level6;
end
end
%}

end

end
end

NumRBFs_Total = size(Phi_V_x,2);

Phi_p = Phi_V_x;
Phi_C_xx = Phi_V_x;
Phi_C_yy = Phi_V_x;
Phi_C_xy = Phi_V_x;

1/(1e-12)
cond(Phi_V_x)
cond(Phi_V_y)

%Sequential RVM (Vector Alpha, Scalar Beta):

nsample = 50;

%U
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_V_x,tn_V_x);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_Vx = rcond(SIGMA)
mN_V = PARAMETER.Value;
Count_Relevant_Index_V = length(PARAMETER.Relevant);
Relevant_Index_V = PARAMETER.Relevant;
logEvidenceFunction_V = PARAMETER.Likelihood;
alpha_star_V = HYPERPARAMETER.Alpha;
beta_star_V = HYPERPARAMETER.beta;
FullSet_V = [1:((NumRBFs_Total))]';
SetDiff_V = setdiff(FullSet_V,Relevant_Index_V);
NumSetDiff_V = length(SetDiff_V);
indicator_vector_V_x(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_V
j1 = SetDiff_V(j);
indicator_vector_V_x(j1,1) = 1;
end
counter = 0;

n_V_x = nsample;
mu_V_x = mN_V;
Phi_V_x_Relevant = Phi_V_x(:,Relevant_Index_V');
SigmaInv_V_x = diag(alpha_star_V) + (beta_star_V*(Phi_V_x_Relevant')*(Phi_V_x_Relevant));
Lambda_V_x = chol( SigmaInv_V_x );
Lambdai_V_x = inv(Lambda_V_x);
Sigma_V_x   = Lambdai_V_x * Lambdai_V_x';
R_V_x_2 = mvnrnd(mu_V_x,Sigma_V_x,n_V_x);

R_V_x = zeros(n_V_x,(NumRBFs_Total));
mN_V_x = zeros((NumRBFs_Total),1);
alpha_star_V_x = zeros((NumRBFs_Total),1);
beta_star_V_x = beta_star_V;
for j = 1:size(FullSet_V,1)
if (indicator_vector_V_x(j,1) == 1)
mN_V_x(j,1) = 0;
alpha_star_V_x(j,1) = inf;
R_V_x(:,j) = zeros(n_V_x,1);
elseif (indicator_vector_V_x(j,1) == 0)
counter = counter + 1;
mN_V_x(j,1) = mN_V(counter,1);
alpha_star_V_x(j,1) = alpha_star_V(counter,1);
R_V_x(:,j) = R_V_x_2(:,counter);
end
end
NumPruned_V_x = sum(indicator_vector_V_x);
Percentage_Pruning_V_x = NumPruned_V_x/NumRBFs_Total

logML_V_x = logEvidenceFunction_V;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_Vx = NumRBFs_Total - NumPruned_V_x;
index_in_model_Vx = zeros(num_unpruned_Vx,1);
Ci_in_model_Vx = zeros(num_unpruned_Vx,2);
alpha_in_model_Vx = zeros(num_unpruned_Vx,1);
mN_in_model_Vx = zeros(num_unpruned_Vx,1);
index_notin_model_Vx = zeros(NumRBFs_Total-num_unpruned_Vx,1);
Ci_notin_model_Vx = zeros(NumRBFs_Total-num_unpruned_Vx,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_V_x(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_Vx(counter1,1) = jjj;
Ci_in_model_Vx(counter1,1) = Ci(jjj,1);
Ci_in_model_Vx(counter1,2) = Ci(jjj,2);
alpha_in_model_Vx(counter1,1) = alpha_star_V_x(jjj,1);
mN_in_model_Vx(counter1,1) = mN_V_x(jjj,1);
elseif (indicator_vector_V_x(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_Vx(counter2,1) = jjj;
Ci_notin_model_Vx(counter2,1) = Ci(jjj,1);
Ci_notin_model_Vx(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_Vx(:,1),Ci_notin_model_Vx(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_Vx;
scatter(Ci_in_model_Vx(:,1),Ci_in_model_Vx(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for U';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

%V
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_V_y,tn_V_y);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_Vy = rcond(SIGMA)
mN_V = PARAMETER.Value;
Count_Relevant_Index_V = length(PARAMETER.Relevant);
Relevant_Index_V = PARAMETER.Relevant;
logEvidenceFunction_V = PARAMETER.Likelihood;
alpha_star_V = HYPERPARAMETER.Alpha;
beta_star_V = HYPERPARAMETER.beta;
FullSet_V = [1:((NumRBFs_Total))]';
SetDiff_V = setdiff(FullSet_V,Relevant_Index_V);
NumSetDiff_V = length(SetDiff_V);
indicator_vector_V_y(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_V
j1 = SetDiff_V(j);
indicator_vector_V_y(j1,1) = 1;
end
counter = 0;

n_V_y = nsample;
mu_V_y = mN_V;
Phi_V_y_Relevant = Phi_V_y(:,Relevant_Index_V');
SigmaInv_V_y = diag(alpha_star_V) + (beta_star_V*(Phi_V_y_Relevant')*(Phi_V_y_Relevant));
Lambda_V_y = chol( SigmaInv_V_y );
Lambdai_V_y = inv(Lambda_V_y);
Sigma_V_y   = Lambdai_V_y * Lambdai_V_y';
R_V_y_2 = mvnrnd(mu_V_y,Sigma_V_y,n_V_y);

R_V_y = zeros(n_V_y,(NumRBFs_Total));
mN_V_y = zeros((NumRBFs_Total),1);
alpha_star_V_y = zeros((NumRBFs_Total),1);
beta_star_V_y = beta_star_V;
for j = 1:size(FullSet_V,1)
if (indicator_vector_V_y(j,1) == 1)
mN_V_y(j,1) = 0;
alpha_star_V_y(j,1) = inf;
R_V_y(:,j) = zeros(n_V_y,1);
elseif (indicator_vector_V_y(j,1) == 0)
counter = counter + 1;
mN_V_y(j,1) = mN_V(counter,1);
alpha_star_V_y(j,1) = alpha_star_V(counter,1);
R_V_y(:,j) = R_V_y_2(:,counter);
end
end
NumPruned_V_y = sum(indicator_vector_V_y);
Percentage_Pruning_V_y = NumPruned_V_y/NumRBFs_Total

logML_V_y = logEvidenceFunction_V;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_Vy = NumRBFs_Total - NumPruned_V_y;
index_in_model_Vy = zeros(num_unpruned_Vy,1);
Ci_in_model_Vy = zeros(num_unpruned_Vy,2);
alpha_in_model_Vy = zeros(num_unpruned_Vy,1);
mN_in_model_Vy = zeros(num_unpruned_Vy,1);
index_notin_model_Vy = zeros(NumRBFs_Total-num_unpruned_Vy,1);
Ci_notin_model_Vy = zeros(NumRBFs_Total-num_unpruned_Vy,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_V_y(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_Vy(counter1,1) = jjj;
Ci_in_model_Vy(counter1,1) = Ci(jjj,1);
Ci_in_model_Vy(counter1,2) = Ci(jjj,2);
alpha_in_model_Vy(counter1,1) = alpha_star_V_y(jjj,1);
mN_in_model_Vy(counter1,1) = mN_V_y(jjj,1);
elseif (indicator_vector_V_y(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_Vy(counter2,1) = jjj;
Ci_notin_model_Vy(counter2,1) = Ci(jjj,1);
Ci_notin_model_Vy(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_Vy(:,1),Ci_notin_model_Vy(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_Vy;
scatter(Ci_in_model_Vy(:,1),Ci_in_model_Vy(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for V';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

%p
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_p,tn_p);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_p = rcond(SIGMA)
mN_p2 = PARAMETER.Value;
Count_Relevant_Index_p = length(PARAMETER.Relevant);
Relevant_Index_p = PARAMETER.Relevant;
logEvidenceFunction_p = PARAMETER.Likelihood;
alpha_star_p2 = HYPERPARAMETER.Alpha;
beta_star_p2 = HYPERPARAMETER.beta;
FullSet_p = [1:((NumRBFs_Total))]';
SetDiff_p = setdiff(FullSet_p,Relevant_Index_p);
NumSetDiff_p = length(SetDiff_p);
indicator_vector_p(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_p
j1 = SetDiff_p(j);
indicator_vector_p(j1,1) = 1;
end
counter = 0;

n_p = nsample;
mu_p = mN_p2;
Phi_p_Relevant = Phi_p(:,Relevant_Index_p');
SigmaInv_p = diag(alpha_star_p2) + (beta_star_p2*(Phi_p_Relevant')*(Phi_p_Relevant));
Lambda_p = chol( SigmaInv_p );
Lambdai_p = inv(Lambda_p);
Sigma_p   = Lambdai_p * Lambdai_p';
R_p_2 = mvnrnd(mu_p,Sigma_p,n_p);

R_p = zeros(n_p,(NumRBFs_Total));
mN_p = zeros((NumRBFs_Total),1);
alpha_star_p = zeros((NumRBFs_Total),1);
beta_star_p = beta_star_p2;
for j = 1:size(FullSet_p,1)
if (indicator_vector_p(j,1) == 1)
mN_p(j,1) = 0;
alpha_star_p(j,1) = inf;
R_p(:,j) = zeros(n_p,1);
elseif (indicator_vector_p(j,1) == 0)
counter = counter + 1;
mN_p(j,1) = mN_p2(counter,1);
alpha_star_p(j,1) = alpha_star_p2(counter,1);
R_p(:,j) = R_p_2(:,counter);
end
end
NumPruned_p = sum(indicator_vector_p);
Percentage_Pruning_p = NumPruned_p/NumRBFs_Total

logML_p = logEvidenceFunction_p;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_p = NumRBFs_Total - NumPruned_p;
index_in_model_p = zeros(num_unpruned_p,1);
Ci_in_model_p = zeros(num_unpruned_p,2);
alpha_in_model_p = zeros(num_unpruned_p,1);
mN_in_model_p = zeros(num_unpruned_p,1);
index_notin_model_p = zeros(NumRBFs_Total-num_unpruned_p,1);
Ci_notin_model_p = zeros(NumRBFs_Total-num_unpruned_p,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_p(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_p(counter1,1) = jjj;
Ci_in_model_p(counter1,1) = Ci(jjj,1);
Ci_in_model_p(counter1,2) = Ci(jjj,2);
alpha_in_model_p(counter1,1) = alpha_star_p(jjj,1);
mN_in_model_p(counter1,1) = mN_p(jjj,1);
elseif (indicator_vector_p(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_p(counter2,1) = jjj;
Ci_notin_model_p(counter2,1) = Ci(jjj,1);
Ci_notin_model_p(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_p(:,1),Ci_notin_model_p(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_p;
scatter(Ci_in_model_p(:,1),Ci_in_model_p(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for p';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

%tauxx:
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_C_xx,tn_C_xx);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_C_xx = rcond(SIGMA)
mN_C_xx2 = PARAMETER.Value;
Count_Relevant_Index_C_xx = length(PARAMETER.Relevant);
Relevant_Index_C_xx = PARAMETER.Relevant;
logEvidenceFunction_C_xx = PARAMETER.Likelihood;
alpha_star_C_xx2 = HYPERPARAMETER.Alpha;
beta_star_C_xx2 = HYPERPARAMETER.beta;
FullSet_C_xx = [1:((NumRBFs_Total))]';
SetDiff_C_xx = setdiff(FullSet_C_xx,Relevant_Index_C_xx);
NumSetDiff_C_xx = length(SetDiff_C_xx);
indicator_vector_C_xx(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_C_xx
j1 = SetDiff_C_xx(j);
indicator_vector_C_xx(j1,1) = 1;
end
counter = 0;

n_C_xx = nsample;
mu_C_xx = mN_C_xx2;
Phi_C_xx_Relevant = Phi_C_xx(:,Relevant_Index_C_xx');
SigmaInv_C_xx = diag(alpha_star_C_xx2) + (beta_star_C_xx2*(Phi_C_xx_Relevant')*(Phi_C_xx_Relevant));
Lambda_C_xx = chol( SigmaInv_C_xx );
Lambdai_C_xx = inv(Lambda_C_xx);
Sigma_C_xx   = Lambdai_C_xx * Lambdai_C_xx';
R_C_xx_2 = mvnrnd(mu_C_xx,Sigma_C_xx,n_C_xx);

R_C_xx = zeros(n_C_xx,(NumRBFs_Total));
mN_C_xx = zeros((NumRBFs_Total),1);
alpha_star_C_xx = zeros((NumRBFs_Total),1);
beta_star_C_xx = beta_star_C_xx2;
for j = 1:size(FullSet_C_xx,1)
if (indicator_vector_C_xx(j,1) == 1)
mN_C_xx(j,1) = 0;
alpha_star_C_xx(j,1) = inf;
R_C_xx(:,j) = zeros(n_C_xx,1);
elseif (indicator_vector_C_xx(j,1) == 0)
counter = counter + 1;
mN_C_xx(j,1) = mN_C_xx2(counter,1);
alpha_star_C_xx(j,1) = alpha_star_C_xx2(counter,1);
R_C_xx(:,j) = R_C_xx_2(:,counter);
end
end
NumPruned_C_xx = sum(indicator_vector_C_xx);
Percentage_Pruning_C_xx = NumPruned_C_xx/NumRBFs_Total

logML_C_xx = logEvidenceFunction_C_xx;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_Cxx = NumRBFs_Total - NumPruned_C_xx;
index_in_model_Cxx = zeros(num_unpruned_Cxx,1);
Ci_in_model_Cxx = zeros(num_unpruned_Cxx,2);
alpha_in_model_Cxx = zeros(num_unpruned_Cxx,1);
mN_in_model_Cxx = zeros(num_unpruned_Cxx,1);
index_notin_model_Cxx = zeros(NumRBFs_Total-num_unpruned_Cxx,1);
Ci_notin_model_Cxx = zeros(NumRBFs_Total-num_unpruned_Cxx,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_C_xx(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_Cxx(counter1,1) = jjj;
Ci_in_model_Cxx(counter1,1) = Ci(jjj,1);
Ci_in_model_Cxx(counter1,2) = Ci(jjj,2);
alpha_in_model_Cxx(counter1,1) = alpha_star_C_xx(jjj,1);
mN_in_model_Cxx(counter1,1) = mN_C_xx(jjj,1);
elseif (indicator_vector_C_xx(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_Cxx(counter2,1) = jjj;
Ci_notin_model_Cxx(counter2,1) = Ci(jjj,1);
Ci_notin_model_Cxx(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_Cxx(:,1),Ci_notin_model_Cxx(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_Cxx;
scatter(Ci_in_model_Cxx(:,1),Ci_in_model_Cxx(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for tauxx';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

%tauyy:
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_C_yy,tn_C_yy);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_C_yy = rcond(SIGMA)
mN_C_yy2 = PARAMETER.Value;
Count_Relevant_Index_C_yy = length(PARAMETER.Relevant);
Relevant_Index_C_yy = PARAMETER.Relevant;
logEvidenceFunction_C_yy = PARAMETER.Likelihood;
alpha_star_C_yy2 = HYPERPARAMETER.Alpha;
beta_star_C_yy2 = HYPERPARAMETER.beta;
FullSet_C_yy = [1:((NumRBFs_Total))]';
SetDiff_C_yy = setdiff(FullSet_C_yy,Relevant_Index_C_yy);
NumSetDiff_C_yy = length(SetDiff_C_yy);
indicator_vector_C_yy(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_C_yy
j1 = SetDiff_C_yy(j);
indicator_vector_C_yy(j1,1) = 1;
end
counter = 0;

n_C_yy = nsample;
mu_C_yy = mN_C_yy2;
Phi_C_yy_Relevant = Phi_C_yy(:,Relevant_Index_C_yy');
SigmaInv_C_yy = diag(alpha_star_C_yy2) + (beta_star_C_yy2*(Phi_C_yy_Relevant')*(Phi_C_yy_Relevant));
Lambda_C_yy = chol( SigmaInv_C_yy );
Lambdai_C_yy = inv(Lambda_C_yy);
Sigma_C_yy   = Lambdai_C_yy * Lambdai_C_yy';
R_C_yy_2 = mvnrnd(mu_C_yy,Sigma_C_yy,n_C_yy);

R_C_yy = zeros(n_C_yy,(NumRBFs_Total));
mN_C_yy = zeros((NumRBFs_Total),1);
alpha_star_C_yy = zeros((NumRBFs_Total),1);
beta_star_C_yy = beta_star_C_yy2;
for j = 1:size(FullSet_C_yy,1)
if (indicator_vector_C_yy(j,1) == 1)
mN_C_yy(j,1) = 0;
alpha_star_C_yy(j,1) = inf;
R_C_yy(:,j) = zeros(n_C_yy,1);
elseif (indicator_vector_C_yy(j,1) == 0)
counter = counter + 1;
mN_C_yy(j,1) = mN_C_yy2(counter,1);
alpha_star_C_yy(j,1) = alpha_star_C_yy2(counter,1);
R_C_yy(:,j) = R_C_yy_2(:,counter);
end
end
NumPruned_C_yy = sum(indicator_vector_C_yy);
Percentage_Pruning_C_yy = NumPruned_C_yy/NumRBFs_Total

logML_C_yy = logEvidenceFunction_C_yy;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_Cyy = NumRBFs_Total - NumPruned_C_yy;
index_in_model_Cyy = zeros(num_unpruned_Cyy,1);
Ci_in_model_Cyy = zeros(num_unpruned_Cyy,2);
alpha_in_model_Cyy = zeros(num_unpruned_Cyy,1);
mN_in_model_Cyy = zeros(num_unpruned_Cyy,1);
index_notin_model_Cyy = zeros(NumRBFs_Total-num_unpruned_Cyy,1);
Ci_notin_model_Cyy = zeros(NumRBFs_Total-num_unpruned_Cyy,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_C_yy(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_Cyy(counter1,1) = jjj;
Ci_in_model_Cyy(counter1,1) = Ci(jjj,1);
Ci_in_model_Cyy(counter1,2) = Ci(jjj,2);
alpha_in_model_Cyy(counter1,1) = alpha_star_C_yy(jjj,1);
mN_in_model_Cyy(counter1,1) = mN_C_yy(jjj,1);
elseif (indicator_vector_C_yy(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_Cyy(counter2,1) = jjj;
Ci_notin_model_Cyy(counter2,1) = Ci(jjj,1);
Ci_notin_model_Cyy(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_Cyy(:,1),Ci_notin_model_Cyy(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_Cyy;
scatter(Ci_in_model_Cyy(:,1),Ci_in_model_Cyy(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for tauyy';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

%tauxy:
[PARAMETER, HYPERPARAMETER, DIAGNOSTIC] = SparseBayes('Gaussian', Phi_C_xy,tn_C_xy);
SIGMA = (PARAMETER.Covariance);
%reciprocalcondnumber_C_xy = rcond(SIGMA)
mN_C_xy2 = PARAMETER.Value;
Count_Relevant_Index_C_xy = length(PARAMETER.Relevant);
Relevant_Index_C_xy = PARAMETER.Relevant;
logEvidenceFunction_C_xy = PARAMETER.Likelihood;
alpha_star_C_xy2 = HYPERPARAMETER.Alpha;
beta_star_C_xy2 = HYPERPARAMETER.beta;
FullSet_C_xy = [1:((NumRBFs_Total))]';
SetDiff_C_xy = setdiff(FullSet_C_xy,Relevant_Index_C_xy);
NumSetDiff_C_xy = length(SetDiff_C_xy);
indicator_vector_C_xy(1:((NumRBFs_Total)),1) = zeros((NumRBFs_Total),1);
for j = 1:NumSetDiff_C_xy
j1 = SetDiff_C_xy(j);
indicator_vector_C_xy(j1,1) = 1;
end
counter = 0;

n_C_xy = nsample;
mu_C_xy = mN_C_xy2;
Phi_C_xy_Relevant = Phi_C_xy(:,Relevant_Index_C_xy');
SigmaInv_C_xy = diag(alpha_star_C_xy2) + (beta_star_C_xy2*(Phi_C_xy_Relevant')*(Phi_C_xy_Relevant));
Lambda_C_xy = chol( SigmaInv_C_xy );
Lambdai_C_xy = inv(Lambda_C_xy);
Sigma_C_xy   = Lambdai_C_xy * Lambdai_C_xy';
R_C_xy_2 = mvnrnd(mu_C_xy,Sigma_C_xy,n_C_xy);

R_C_xy = zeros(n_C_xy,(NumRBFs_Total));
mN_C_xy = zeros((NumRBFs_Total),1);
alpha_star_C_xy = zeros((NumRBFs_Total),1);
beta_star_C_xy = beta_star_C_xy2;
for j = 1:size(FullSet_C_xy,1)
if (indicator_vector_C_xy(j,1) == 1)
mN_C_xy(j,1) = 0;
alpha_star_C_xy(j,1) = inf;
R_C_xy(:,j) = zeros(n_C_xy,1);
elseif (indicator_vector_C_xy(j,1) == 0)
counter = counter + 1;
mN_C_xy(j,1) = mN_C_xy2(counter,1);
alpha_star_C_xy(j,1) = alpha_star_C_xy2(counter,1);
R_C_xy(:,j) = R_C_xy_2(:,counter);
end
end
NumPruned_C_xy = sum(indicator_vector_C_xy);
Percentage_Pruning_C_xy = NumPruned_C_xy/NumRBFs_Total

logML_C_xy = logEvidenceFunction_C_xy;

%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2)];
%Ci = [Ci_level1_2(:,1) Ci_level1_2(:,2); Ci_level2_2(:,1) Ci_level2_2(:,2); Ci_level3_2(:,1) Ci_level3_2(:,2); ...
%    Ci_level4_2(:,1) Ci_level4_2(:,2); Ci_level5_2(:,1) Ci_level5_2(:,2); Ci_level6_2(:,1) Ci_level6_2(:,2)];

num_unpruned_Cxy = NumRBFs_Total - NumPruned_C_xy;
index_in_model_Cxy = zeros(num_unpruned_Cxy,1);
Ci_in_model_Cxy = zeros(num_unpruned_Cxy,2);
alpha_in_model_Cxy = zeros(num_unpruned_Cxy,1);
mN_in_model_Cxy = zeros(num_unpruned_Cxy,1);
index_notin_model_Cxy = zeros(NumRBFs_Total-num_unpruned_Cxy,1);
Ci_notin_model_Cxy = zeros(NumRBFs_Total-num_unpruned_Cxy,2);
counter1 = 0;
counter2 = 0;
for jjj = 1:1:NumRBFs_Total
index =  jjj;  
if (indicator_vector_C_xy(index,1) == 0)
counter1 = counter1 + 1;
index_in_model_Cxy(counter1,1) = jjj;
Ci_in_model_Cxy(counter1,1) = Ci(jjj,1);
Ci_in_model_Cxy(counter1,2) = Ci(jjj,2);
alpha_in_model_Cxy(counter1,1) = alpha_star_C_xy(jjj,1);
mN_in_model_Cxy(counter1,1) = mN_C_xy(jjj,1);
elseif (indicator_vector_C_xy(index,1) == 1)
counter2 = counter2 + 1;
index_notin_model_Cxy(counter2,1) = jjj;
Ci_notin_model_Cxy(counter2,1) = Ci(jjj,1);
Ci_notin_model_Cxy(counter2,2) = Ci(jjj,2);
end    
end

figure;
hold on;
%sz = 36;
sz = 60; 
scatter(Ci_notin_model_Cxy(:,1),Ci_notin_model_Cxy(:,2),sz,'Marker','square','MarkerFaceColor',[0 0 0]);
hold on;
%sz = 300;
sz = 600;
c1 = alpha_in_model_Cxy;
scatter(Ci_in_model_Cxy(:,1),Ci_in_model_Cxy(:,2),sz,c1,'filled','Marker','square');
c2 = colorbar;
c2.Label.String = '\alpha for tauxy';
xlabel('x');
ylabel('y');
axis square;
axis tight;
set(gca,'ColorScale','log')

save('10_Percent_SubDomain_CredibleIntervals/logML_17x17RBFs.mat','logML_V_x','logML_V_y','logML_p','logML_C_xx','logML_C_yy','logML_C_xy');

%% Contour plots %%

N = 50;
%N = 200;
%N = 500;
h = 1;
dx = h/N;
x = [((-h/2)+(dx/2)):dx:((h/2)-(dx/2))]';
y = x;

%U
VxCorr = zeros(N,N);
VxCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    VxCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    VxCorr_2(index2,1) = correction1;

    else

    VxCorr(II,JJ) = NaN;
    %VxCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    VxCorr_2(index2,1) = NaN;
    %VxCorr_2(index2,1) = 0.0;

    end

end
end

VxCorr_Mat = zeros(N,N,n_V_x);

for np = 1:1:n_V_x 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    VxCorr_Mat(II,JJ,np) = correction1;

    else

    VxCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_V_x_2 = 50;

VxCorr_Upper = zeros(N,N);
VxCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

VxCorr_1D(1:n_V_x_2,1) = VxCorr_Mat(II,JJ,1:n_V_x_2);    
VxCorr_Upper(II,JJ) = prctile(VxCorr_1D,100-percent);
VxCorr_Lower(II,JJ) = prctile(VxCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,VxCorr');
hold on;
contour(X,Y,VxCorr_Lower','r--');
hold on;
contour(X,Y,VxCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis equal;
axis tight;

U(1:N,1:N) = Velocity_BM(1,1:N,1:N);

figure;
hold on;
plot(x,U(:,end),'k--',LineWidth=1);
hold on;
plot(x,VxCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [VxCorr_Lower(:,end)' fliplr(VxCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('U');
axis square;
axis tight;

%V
VyCorr = zeros(N,N);
VyCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
  
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{      
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    VyCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    VyCorr_2(index2,1) = correction1;

    else

    VyCorr(II,JJ) = NaN;
    %VyCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    VyCorr_2(index2,1) = NaN;
    %VyCorr_2(index2,1) = 0.0;

    end

end
end

VyCorr_Mat = zeros(N,N,n_V_y);

for np = 1:1:n_V_y 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    VyCorr_Mat(II,JJ,np) = correction1;

    else

    VyCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_V_y_2 = 50;

VyCorr_Upper = zeros(N,N);
VyCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

VyCorr_1D(1:n_V_y_2,1) = VyCorr_Mat(II,JJ,1:n_V_y_2);    
VyCorr_Upper(II,JJ) = prctile(VyCorr_1D,100-percent);
VyCorr_Lower(II,JJ) = prctile(VyCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,VyCorr');
hold on;
contour(X,Y,VyCorr_Lower','r--');
hold on;
contour(X,Y,VyCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U';
axis equal;
axis tight;

V(1:N,1:N) = Velocity_BM(2,1:N,1:N);

figure;
hold on;
plot(x,V(:,end),'k--',LineWidth=1);
hold on;
plot(x,VyCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [VyCorr_Lower(:,end)' fliplr(VyCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('V');
axis square;
axis tight;

%p
pCorr = zeros(N,N);
pCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_p(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_p(counter,1);
    end
    end

    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_p(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_p(counter,1);
    end
    end

    %{      
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_p(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_p(counter,1);
    end
    end
    %}
    
    pCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    pCorr_2(index2,1) = correction1;

    else

    pCorr(II,JJ) = NaN;
    %pCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    pCorr_2(index2,1) = NaN;
    %pCorr_2(index2,1) = 0.0;

    end
end
end

pCorr_Mat = zeros(N,N,n_p);

for np = 1:1:n_p

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_p(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_p(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_p(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_p(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_p(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_p(np,counter);
    end
    end
    %}
    
    pCorr_Mat(II,JJ,np) = correction1;

    else

    pCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_p_2 = 50;

pCorr_Upper = zeros(N,N);
pCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

pCorr_1D(1:n_p_2,1) = pCorr_Mat(II,JJ,1:n_p_2);    
pCorr_Upper(II,JJ) = prctile(pCorr_1D,100-percent);
pCorr_Lower(II,JJ) = prctile(pCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,pCorr');
hold on;
contour(X,Y,pCorr_Lower','r--');
hold on;
contour(X,Y,pCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p';
axis equal;
axis tight;

p(1:N,1:N) = Pressure_BM(1:N,1:N);

figure;
hold on;
plot(x,p(:,end),'k--',LineWidth=1);
hold on;
plot(x,pCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [pCorr_Lower(:,end)' fliplr(pCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('p');
axis square;
axis tight;

%Tauxx
tauxxCorr = zeros(N,N);
tauxxCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xx(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xx(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xx(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xx(counter,1);
    end
    end
    
    %{      
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xx(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xx(counter,1);
    end
    end
    %}
    
    tauxxCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    tauxxCorr_2(index2,1) = correction1;

    else

    tauxxCorr(II,JJ) = NaN;
    %tauxxCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    tauxxCorr_2(index2,1) = NaN;
    %tauxxCorr_2(index2,1) = 0.0;

    end

end
end

tauxxCorr_Mat = zeros(N,N,n_C_xx);

for np = 1:1:n_C_xx 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xx(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xx(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xx(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xx(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xx(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xx(np,counter);
    end
    end
    %}
    
    tauxxCorr_Mat(II,JJ,np) = correction1;

    else

    tauxxCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_C_xx_2 = 50;

tauxxCorr_Upper = zeros(N,N);
tauxxCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

tauxxCorr_1D(1:n_C_xx_2,1) = tauxxCorr_Mat(II,JJ,1:n_C_xx_2);    
tauxxCorr_Upper(II,JJ) = prctile(tauxxCorr_1D,100-percent);
tauxxCorr_Lower(II,JJ) = prctile(tauxxCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxxCorr');
hold on;
contour(X,Y,tauxxCorr_Lower','r--');
hold on;
contour(X,Y,tauxxCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxx';
axis equal;
axis tight;

tauxx = Tauxx_BM(1:N,1:N) - Pressure_BM(1:N,1:N);

figure;
hold on;
plot(x,tauxx(:,end),'k--',LineWidth=1);
hold on;
plot(x,tauxxCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [tauxxCorr_Lower(:,end)' fliplr(tauxxCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('tauxx');
axis square;
axis tight;

%Tauyy
tauyyCorr = zeros(N,N);
tauyyCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_yy(counter,1);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_yy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_yy(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_yy(counter,1);
    end
    end
    
    %{  
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_yy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_yy(counter,1);
    end
    end
    %}
    
    tauyyCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    tauyyCorr_2(index2,1) = correction1;

    else

    tauyyCorr(II,JJ) = NaN;
    %tauyyCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    tauyyCorr_2(index2,1) = NaN;
    %tauyyCorr_2(index2,1) = 0.0;

    end

end
end

tauyyCorr_Mat = zeros(N,N,n_C_yy);

for np = 1:1:n_C_yy 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_yy(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_yy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_yy(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_yy(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_yy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_yy(np,counter);
    end
    end
    %}
    
    tauyyCorr_Mat(II,JJ,np) = correction1;

    else

    tauyyCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_C_yy_2 = 50;

tauyyCorr_Upper = zeros(N,N);
tauyyCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

tauyyCorr_1D(1:n_C_yy_2,1) = tauyyCorr_Mat(II,JJ,1:n_C_yy_2);    
tauyyCorr_Upper(II,JJ) = prctile(tauyyCorr_1D,100-percent);
tauyyCorr_Lower(II,JJ) = prctile(tauyyCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauyyCorr');
hold on;
contour(X,Y,tauyyCorr_Lower','r--');
hold on;
contour(X,Y,tauyyCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauyy';
axis equal;
axis tight;

tauyy = Tauyy_BM(1:N,1:N) - Pressure_BM(1:N,1:N);

figure;
hold on;
plot(x,tauyy(:,end),'k--',LineWidth=1);
hold on;
plot(x,tauyyCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [tauyyCorr_Lower(:,end)' fliplr(tauyyCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('tauxx');
axis square;
axis tight;

%Tauxy
tauxyCorr = zeros(N,N);
tauxyCorr_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xy(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xy(counter,1);
    end
    end

    %{      
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xy(counter,1);
    end
    end
    %}

    tauxyCorr(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    tauxyCorr_2(index2,1) = correction1;

    else

    tauxyCorr(II,JJ) = NaN;
    %tauxyCorr(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    tauxyCorr_2(index2,1) = NaN;
    %tauxyCorr_2(index2,1) = 0.0;

    end

end
end

tauxyCorr_Mat = zeros(N,N,n_C_xy);

for np = 1:1:n_C_xy 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xy(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xy(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xy(np,counter);
    end
    end
    
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xy(np,counter);
    end
    end
    %}
    
    tauxyCorr_Mat(II,JJ,np) = correction1;

    else

    tauxyCorr_Mat(II,JJ,np) = NaN;

    end

end
end

end

n_C_xy_2 = 50;

tauxyCorr_Upper = zeros(N,N);
tauxyCorr_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

tauxyCorr_1D(1:n_C_xy_2,1) = tauxyCorr_Mat(II,JJ,1:n_C_xy_2);    
tauxyCorr_Upper(II,JJ) = prctile(tauxyCorr_1D,100-percent);
tauxyCorr_Lower(II,JJ) = prctile(tauxyCorr_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxyCorr');
hold on;
contour(X,Y,tauxyCorr_Lower','r--');
hold on;
contour(X,Y,tauxyCorr_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxy';
axis equal;
axis tight;

tauxy = Tauxy_BM(1:N,1:N);

figure;
hold on;
plot(x,tauxy(:,end),'k--',LineWidth=1);
hold on;
plot(x,tauxyCorr(:,end),'r--',LineWidth=1);
hold on;
fill([x' fliplr(x')], [tauxyCorr_Lower(:,end)' fliplr(tauxyCorr_Upper(:,end)')],['g'],'EdgeColor','g','FaceAlpha','0.2');
hold on;
xlabel('x');
ylabel('tauxx');
axis square;
axis tight;

%% Save to file velocity and pressure fits %%

figure;
hold on;
U_fit(1:N,1:N) = VxCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,U_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'U_fit (m/s)';
axis equal;
axis tight;

figure;
hold on;
V_fit(1:N,1:N) = VyCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,V_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'V_fit (m/s)';
axis equal;
axis tight;

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Interior_Data_nsample_0.dat']);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g %g\n',U_fit(I,J), V_fit(I,J));
end
end
fclose(fileID);

for nn = 1:1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Interior_Data_nsample_%d.dat'],nn);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g %g\n',VxCorr_Mat(I,J,nn), VyCorr_Mat(I,J,nn));
end
end
fclose(fileID);

end    

figure;
hold on;
p_fit(1:N,1:N) = pCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,p_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'p_fit';
axis equal;
axis tight;

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Interior_Data_nsample_0.dat']);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g\n',p_fit(I,J));
end
end
fclose(fileID);

for nn = 1:1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Interior_Data_nsample_%d.dat'],nn);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g\n',pCorr_Mat(I,J,nn));
end
end
fclose(fileID);

end    

figure;
hold on;
tauxx_fit(1:N,1:N) = tauxxCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxx_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxx_fit';
axis equal;
axis tight;

figure;
hold on;
tauyy_fit(1:N,1:N) = tauyyCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauyy_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauyy_fit';
axis equal;
axis tight;

figure;
hold on;
tauxy_fit(1:N,1:N) = tauxyCorr(1:N,1:N);
[X,Y] = meshgrid(x,y);
contourf(X,Y,tauxy_fit');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'tauxy_fit';
axis equal;
axis tight;

%% Analytical calculation of Stress Corrections %%

%du/dx
dudx = zeros(N,N);
dudx_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudx(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    dudx_2(index2,1) = correction1;

    else

    dudx(II,JJ) = NaN;
    %dudx(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    dudx_2(index2,1) = NaN;
    %dudx_2(index2,1) = 0.0;

    end

end
end

dudx_Mat = zeros(N,N,n_V_x);

for np = 1:1:n_V_x 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )        
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudx_Mat(II,JJ,np) = correction1;

    else

    dudx_Mat(II,JJ,np) = NaN;

    end

end
end

end

dudx_Upper = zeros(N,N);
dudx_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

dudx_1D(1:n_V_x,1) = dudx_Mat(II,JJ,1:n_V_x);    
dudx_Upper(II,JJ) = prctile(dudx_1D,100-percent);
dudx_Lower(II,JJ) = prctile(dudx_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dudx');
hold on;
contour(X,Y,dudx_Lower','r--');
hold on;
contour(X,Y,dudx_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dudx';
axis equal;
axis tight;

%dv/dy
dvdy = zeros(N,N);
dvdy_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdy(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    dvdy_2(index2,1) = correction1;

    else

    dvdy(II,JJ) = NaN;
    %dvdy(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    dvdy_2(index2,1) = NaN;
    %dvdy_2(index2,1) = 0.0;

    end

end
end

dvdy_Mat = zeros(N,N,n_V_y);

for np = 1:1:n_V_y 

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);

    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdy_Mat(II,JJ,np) = correction1;

    else

    dvdy_Mat(II,JJ,np) = NaN;

    end

end
end

end

dvdy_Upper = zeros(N,N);
dvdy_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

dvdy_1D(1:n_V_y,1) = dvdy_Mat(II,JJ,1:n_V_y);    
dvdy_Upper(II,JJ) = prctile(dvdy_1D,100-percent);
dvdy_Lower(II,JJ) = prctile(dvdy_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dvdy');
hold on;
contour(X,Y,dvdy_Lower','r--');
hold on;
contour(X,Y,dvdy_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dvdy';
axis equal;
axis tight;

%du/dy
dudy = zeros(N,N);
dudy_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);
    
    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudy(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    dudy_2(index2,1) = correction1;

    else

    dudy(II,JJ) = NaN;
    %dudy(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    dudy_2(index2,1) = NaN;
    %dudy_2(index2,1) = 0.0;

    end

end
end

dudy_Mat = zeros(N,N,n_V_x);

for np = 1:1:n_V_x  

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);
    
    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudy_Mat(II,JJ,np) = correction1;

    else

    dudy_Mat(II,JJ,np) = NaN;

    end

end
end

end

dudy_Upper = zeros(N,N);
dudy_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

dudy_1D(1:n_V_y,1) = dudy_Mat(II,JJ,1:n_V_x);    
dudy_Upper(II,JJ) = prctile(dudy_1D,100-percent);
dudy_Lower(II,JJ) = prctile(dudy_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dudy');
hold on;
contour(X,Y,dudy_Lower','r--');
hold on;
contour(X,Y,dudy_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dudy';
axis equal;
axis tight;

%dv/dx
dvdx = zeros(N,N);
dvdx_2 = zeros(N*N,1);

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);
    
    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdx(II,JJ) = correction1;
    index2 = II + (JJ-1)*N;
    dvdx_2(index2,1) = correction1;

    else

    dvdx(II,JJ) = NaN;
    %dvdx(II,JJ) = 0.0;
    index2 = II + (JJ-1)*N;
    dvdx_2(index2,1) = NaN;
    %dvdx_2(index2,1) = 0.0;

    end

end
end

dvdx_Mat = zeros(N,N,n_V_y);

for np = 1:1:n_V_y   

for JJ = 1:N
for II = 1:N
    x_grid = y(II);
    y_grid = y(JJ);
    
    distance_x = abs(x_grid);
    distance_y = abs(y_grid);    
    if ( (distance_x >= (0.5 - Cutoff_Distance)) || (distance_y >= (0.5 - Cutoff_Distance)) )

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdx_Mat(II,JJ,np) = correction1;

    else

    dvdx_Mat(II,JJ,np) = NaN;

    end

end
end

end

dvdx_Upper = zeros(N,N);
dvdx_Lower = zeros(N,N);
percent = 2.5;

for JJ = 1:N
for II = 1:N

dvdx_1D(1:n_V_x,1) = dvdx_Mat(II,JJ,1:n_V_y);    
dvdx_Upper(II,JJ) = prctile(dvdx_1D,100-percent);
dvdx_Lower(II,JJ) = prctile(dvdx_1D,percent);

end
end

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dvdx');
hold on;
contour(X,Y,dvdx_Lower','r--');
hold on;
contour(X,Y,dvdx_Upper','r--');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dvdx';
axis equal;
axis tight;

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/Distribution_Approx_Data_nsample_%d.mat'], nsample);
save(filename,'VxCorr_Mat','VyCorr_Mat','pCorr_Mat','tauxxCorr_Mat','tauyyCorr_Mat','tauxyCorr_Mat','dudx_Mat','dvdy_Mat','dudy_Mat','dvdx_Mat');

muE = 2.117e-5;  

phixx(1:N,1:N) = tauxx_fit(1:N,1:N) + (2*muE*dudx(1:N,1:N));
phiyy(1:N,1:N) = tauyy_fit(1:N,1:N) + (2*muE*dvdy(1:N,1:N));
phixy(1:N,1:N) = tauxy_fit(1:N,1:N) + (muE*(dudy(1:N,1:N) + dvdx(1:N,1:N)));

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dudx');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dudx';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phixx');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phixx';
axis square;
axis tight;

phixx_2 = (1/2)*(phixx - phiyy);

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phixx_2');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = '(1/2)*(phixx - phiyy)';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dvdy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dvdy';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phiyy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phiyy';
axis square;
axis tight;

phiyy_2 = (1/2)*(phiyy - phixx);

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phiyy_2');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = '(1/2)*(phiyy - phixx)';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dudy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dudy';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,dvdx');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'dvdx';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phixy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phixy';
axis square;
axis tight;

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g\n',tauxx_fit(I,J), dudx(I,J), tauyy_fit(I,J), dvdy(I,J), tauxy_fit(I,J), dudy(I,J), dvdx(I,J));
end
end
fclose(fileID);

for nn = 1:1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for J = 1:N
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g\n',tauxxCorr_Mat(I,J,nn), dudx_Mat(I,J,nn), tauyyCorr_Mat(I,J,nn), dvdy_Mat(I,J,nn), tauxyCorr_Mat(I,J,nn), dudy_Mat(I,J,nn), dvdx_Mat(I,J,nn));
end
end
fclose(fileID);

end    

%% Boundary Corrections %%

%Velocity:

%Approx:
filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Approx_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g\n', U_fit(1,I), V_fit(1,I), U_fit(N,I), V_fit(N,I), U_fit(I,1), V_fit(I,1), U_fit(I,N), V_fit(I,N));
end
fclose(fileID);

for nn = 1:1:n_V_x

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Approx_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g\n', VxCorr_Mat(1,I,nn), VyCorr_Mat(1,I,nn), VxCorr_Mat(N,I,nn), VyCorr_Mat(N,I,nn), VxCorr_Mat(I,1,nn), VyCorr_Mat(I,1,nn), VxCorr_Mat(I,N,nn), VyCorr_Mat(I,N,nn));
end
fclose(fileID);

end

%Exact:

%Left wall:

%U
VxCorr_left = zeros(N,1);
for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    VxCorr_left(JJ,1) = correction1;
end

VxCorr_Mat_left = zeros(N,n_V_x);

for np = 1:1:n_V_x   

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    VxCorr_Mat_left(JJ,np) = correction1;

end

end

%V
VyCorr_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
  
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    VyCorr_left(JJ,1) = correction1;
end

VyCorr_Mat_left = zeros(N,n_V_y);

for np = 1:1:n_V_y  

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
  
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    VyCorr_Mat_left(JJ,np) = correction1;
end

end

%Right wall:

%U
VxCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    VxCorr_right(JJ,1) = correction1;
end

VxCorr_Mat_right = zeros(N,n_V_x);

for np = 1:1:n_V_x   

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    VxCorr_Mat_right(JJ,np) = correction1;
end

end

%V
VyCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}

    VyCorr_right(JJ,1) = correction1;
end

VyCorr_Mat_right = zeros(N,n_V_y);

for np = 1:1:n_V_y    

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}

    VyCorr_Mat_right(JJ,np) = correction1;
end

end

%Bottom wall:

%U
VxCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    VxCorr_bottom(II,1) = correction1;
end

VxCorr_Mat_bottom = zeros(N,n_V_x);

for np = 1:1:n_V_x    
 
for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    VxCorr_Mat_bottom(II,np) = correction1;

end

end

%V
VyCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    VyCorr_bottom(II,1) = correction1;
end

VyCorr_Mat_bottom = zeros(N,n_V_y);

for np = 1:1:n_V_y  

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    VyCorr_Mat_bottom(II,np) = correction1;
end   
    
end

%Top wall:

%U
VxCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    VxCorr_top(II,1) = correction1;
end

VxCorr_Mat_top = zeros(N,n_V_x);

for np = 1:1:n_V_x    
    
for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    VxCorr_Mat_top(II,np) = correction1;
end   
    
end

%V
VyCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
 
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    VyCorr_top(II,1) = correction1;
end

VyCorr_Mat_top = zeros(N,n_V_y);

for np = 1:1:n_V_y    
    
for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
 
    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    VyCorr_Mat_top(II,np) = correction1;
end   
    
end

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Exact_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g\n', VxCorr_left(I,1), VyCorr_left(I,1), VxCorr_right(I,1), VyCorr_right(I,1), VxCorr_bottom(I,1), VyCorr_bottom(I,1), VxCorr_top(I,1), VyCorr_top(I,1));
end
fclose(fileID);

for nn = 1:1:n_V_x

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Velocity_Exact_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g\n', VxCorr_Mat_left(I,nn), VyCorr_Mat_left(I,nn), VxCorr_Mat_right(I,nn), VyCorr_Mat_right(I,nn), VxCorr_Mat_bottom(I,nn), VyCorr_Mat_bottom(I,nn), VxCorr_Mat_top(I,nn), VyCorr_Mat_top(I,nn));
end
fclose(fileID);

end

%Pressure:

%Approx:

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Approx_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g\n', p_fit(1,I), p_fit(N,I), p_fit(I,1), p_fit(I,N));
end
fclose(fileID);

for nn = 1:1:n_p

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Approx_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g\n', pCorr_Mat(1,I,nn), pCorr_Mat(N,I,nn), pCorr_Mat(I,1,nn), pCorr_Mat(I,N,nn));
end
fclose(fileID);

end

%Exact:

%Left wall:

pCorr_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_p(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_p(counter,1);
    end
    end

    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_p(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_p(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_p(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_p(counter,1);
    end
    end
    %}
    
    pCorr_left(JJ,1) = correction1;
end

pCorr_Mat_left = zeros(N,n_p);

for np = 1:1:n_p    
    
for JJ = 1:N

    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_p(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_p(np,counter);
    end
    end

    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_p(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_p(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_p(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_p(np,counter);
    end
    end
    %}
    
    pCorr_Mat_left(JJ,np) = correction1;
end

end

%Right wall:

pCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_p(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_p(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_p(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_p(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_p(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_p(counter,1);
    end
    end
    %}
    
    pCorr_right(JJ,1) = correction1;
end

pCorr_Mat_right = zeros(N,n_p);

for np = 1:1:n_p  

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_p(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_p(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_p(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_p(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_p(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_p(np,counter);
    end
    end
    %}
    
    pCorr_Mat_right(JJ,np) = correction1;
end
    
end

%Bottom wall:

pCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_p(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_p(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_p(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_p(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_p(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_p(counter,1);
    end
    end
    %}
    
    pCorr_bottom(II,1) = correction1;
end

pCorr_Mat_bottom = zeros(N,n_p);

for np = 1:1:n_p   

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_p(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_p(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_p(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_p(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_p(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_p(np,counter);
    end
    end
    %}
    
    pCorr_Mat_bottom(II,np) = correction1;
end
    
end

%Top wall:

pCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_p(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_p(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_p(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_p(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_p(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_p(counter,1);
    end
    end
    %}
    
    pCorr_top(II,1) = correction1;
end

pCorr_Mat_top = zeros(N,n_p);

for np = 1:1:n_p   

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_p(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_p(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_p(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_p(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_p(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_p(np,counter);
    end
    end
    %}
    
    pCorr_Mat_top(II,np) = correction1;
end
    
end

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Exact_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g\n', pCorr_left(I,1), pCorr_right(I,1), pCorr_bottom(I,1), pCorr_top(I,1));
end
fclose(fileID);

for nn = 1:1:n_p

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Exact_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g\n', pCorr_Mat_left(I,nn), pCorr_Mat_right(I,nn), pCorr_Mat_bottom(I,nn), pCorr_Mat_top(I,nn));
end
fclose(fileID);

end

%Stress corrections:

%Approx:

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Approx_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n', ...
    tauxx_fit(1,I), dudx(1,I), tauyy_fit(1,I), dvdy(1,I), tauxy_fit(1,I), dudy(1,I), dvdx(1,I), ...
    tauxx_fit(N,I), dudx(N,I), tauyy_fit(N,I), dvdy(N,I), tauxy_fit(N,I), dudy(N,I), dvdx(N,I), ...
    tauxx_fit(I,1), dudx(I,1), tauyy_fit(I,1), dvdy(I,1), tauxy_fit(I,1), dudy(I,1), dvdx(I,1), ...
    tauxx_fit(I,N), dudx(I,N), tauyy_fit(I,N), dvdy(I,N), tauxy_fit(I,N), dudy(I,N), dvdx(I,N));
end
fclose(fileID);

for nn = 1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Approx_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n', ...
    tauxxCorr_Mat(1,I,nn), dudx_Mat(1,I,nn), tauyyCorr_Mat(1,I,nn), dvdy_Mat(1,I,nn), tauxyCorr_Mat(1,I,nn), dudy_Mat(1,I,nn), dvdx_Mat(1,I,nn), ...
    tauxxCorr_Mat(N,I,nn), dudx_Mat(N,I,nn), tauyyCorr_Mat(N,I,nn), dvdy_Mat(N,I,nn), tauxyCorr_Mat(N,I,nn), dudy_Mat(N,I,nn), dvdx_Mat(N,I,nn), ...
    tauxxCorr_Mat(I,1,nn), dudx_Mat(I,1,nn), tauyyCorr_Mat(I,1,nn), dvdy_Mat(I,1,nn), tauxyCorr_Mat(I,1,nn), dudy_Mat(I,1,nn), dvdx_Mat(I,1,nn), ...
    tauxxCorr_Mat(I,N,nn), dudx_Mat(I,N,nn), tauyyCorr_Mat(I,N,nn), dvdy_Mat(I,N,nn), tauxyCorr_Mat(I,N,nn), dudy_Mat(I,N,nn), dvdx_Mat(I,N,nn));
end
fclose(fileID);

end

%Exact:

%Left wall:

%Tauxx
tauxxCorr_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xx(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xx(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xx(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xx(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xx(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xx(counter,1);
    end
    end
    %}
    
    tauxxCorr_left(JJ,1) = correction1;
end

tauxxCorr_Mat_left = zeros(N,n_C_xx);

for np = 1:1:n_C_xx    
    
for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xx(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xx(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xx(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xx(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xx(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xx(np,counter);
    end
    end
    %}
    
    tauxxCorr_Mat_left(JJ,np) = correction1;
end
    
end

%du/dx
dudx_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudx_left(JJ,1) = correction1;
end

dudx_Mat_left = zeros(N,n_V_x);

for np = 1:1:n_V_x 

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudx_Mat_left(JJ,np) = correction1;
end 
    
end

%Tauyy
tauyyCorr_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_yy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_yy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_yy(counter,1);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_yy(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_yy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_yy(counter,1);
    end
    end
    %}
    
    tauyyCorr_left(JJ,1) = correction1;
end

tauyyCorr_Mat_left = zeros(N,n_C_yy);

for np = 1:1:n_C_yy 

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_yy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_yy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_yy(np,counter);
    end
    end

    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_yy(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_yy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_yy(np,counter);
    end
    end
    %}
    
    tauyyCorr_Mat_left(JJ,np) = correction1;
end    
    
end

%dv/dy
dvdy_left = zeros(N,N);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdy_left(JJ,1) = correction1;
end

dvdy_Mat_left = zeros(N,n_V_y);

for np = 1:1:n_V_y    
    
for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdy_Mat_left(JJ,np) = correction1;
end
    
end

%Tauxy
tauxyCorr_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xy(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xy(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xy(counter,1);
    end
    end
    %}
    
    tauxyCorr_left(JJ,1) = correction1;
end

tauxyCorr_Mat_left = zeros(N,n_C_xy);

for np = 1:1:n_C_xy 

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xy(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xy(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xy(np,counter);
    end
    end
    %}
    
    tauxyCorr_Mat_left(JJ,np) = correction1;
end  
    
end

%du/dy
dudy_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}

    dudy_left(JJ,1) = correction1;
end

dudy_Mat_left = zeros(N,n_V_x);

for np = 1:1:n_V_x    

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}

    dudy_Mat_left(JJ,np) = correction1;
end
    
end

%dv/dx
dvdx_left = zeros(N,1);

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdx_left(JJ,1) = correction1;
end

dvdx_Mat_left = zeros(N,n_V_y);

for np = 1:1:n_V_y 

for JJ = 1:N
    x_grid = -0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdx_Mat_left(JJ,np) = correction1;
end 
    
end

%Right wall:

%Tauxx
tauxxCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xx(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xx(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xx(counter,1);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xx(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xx(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xx(counter,1);
    end
    end
    %}
    
    tauxxCorr_right(JJ,1) = correction1;
end

tauxxCorr_Mat_right = zeros(N,n_C_xx);

for np = 1:1:n_C_xx  

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xx(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xx(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xx(np,counter);
    end
    end
 
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xx(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xx(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xx(np,counter);
    end
    end
    %}
    
    tauxxCorr_Mat_right(JJ,np) = correction1;
end
    
end

%du/dx
dudx_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
        
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudx_right(JJ,1) = correction1;
end

dudx_Mat_right = zeros(N,n_V_x);

for np = 1:1:n_V_x

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
        
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudx_Mat_right(JJ,np) = correction1;
end 
    
end

%Tauyy
tauyyCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_yy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_yy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_yy(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_yy(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_yy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_yy(counter,1);
    end
    end
    %}
    
    tauyyCorr_right(JJ,1) = correction1;
end

tauyyCorr_Mat_right = zeros(N,n_C_yy);

for np = 1:1:n_C_yy 

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_yy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_yy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_yy(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_yy(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_yy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_yy(np,counter);
    end
    end
    %}
    
     tauyyCorr_Mat_right(JJ,np) = correction1;
end    
    
end

%dv/dy
dvdy_right = zeros(N,N);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdy_right(JJ,1) = correction1;
end

dvdy_Mat_right = zeros(N,n_V_y);

for np = 1:1:n_V_y 

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdy_Mat_right(JJ,np) = correction1;
end
    
end

%Tauxy
tauxyCorr_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xy(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xy(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xy(counter,1);
    end
    end
    %}

    tauxyCorr_right(JJ,1) = correction1;
end

tauxyCorr_Mat_right = zeros(N,n_C_xy);

for np = 1:1:n_C_xy  

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xy(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xy(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xy(np,counter);
    end
    end
    %}

    tauxyCorr_Mat_right(JJ,np) = correction1;
end  
    
end

%du/dy
dudy_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;        
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_x(counter,1);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudy_right(JJ,1) = correction1;
end

dudy_Mat_right = zeros(N,n_V_x);

for np = 1:1:n_V_x  

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;        
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_x(np,counter);
    end
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudy_Mat_right(JJ,np) = correction1;
end
    
end

%dv/dx
dvdx_right = zeros(N,1);

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;        
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdx_right(JJ,1) = correction1;
end

dvdx_Mat_right = zeros(N,n_V_y);

for np = 1:1:n_V_y   

for JJ = 1:N
    x_grid = 0.5;
    y_grid = y(JJ);

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;        
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdx_Mat_right(JJ,np) = correction1;
end 
    
end

%Bottom wall:

%Tauxx
tauxxCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xx(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xx(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xx(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xx(counter,1);
    end
    end
   
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xx(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xx(counter,1);
    end
    end
    %}
    
    tauxxCorr_bottom(II,1) = correction1;
end

tauxxCorr_Mat_bottom = zeros(N,n_C_xx);

for np = 1:1:n_C_xx 

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xx(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xx(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xx(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xx(np,counter);
    end
    end
   
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xx(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xx(np,counter);
    end
    end
    %}
    
    tauxxCorr_Mat_bottom(II,np) = correction1;
end
    
end

%du/dx
dudx_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudx_bottom(II,1) = correction1;
end

dudx_Mat_bottom = zeros(N,n_V_x);

for np = 1:1:n_V_x  

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudx_Mat_bottom(II,np) = correction1;
end 
    
end

%Tauyy
tauyyCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_yy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_yy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_yy(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_yy(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_yy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_yy(counter,1);
    end
    end
    %}
    
    tauyyCorr_bottom(II,1) = correction1;
end

tauyyCorr_Mat_bottom = zeros(N,n_C_yy);

for np = 1:1:n_C_yy    

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_yy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_yy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_yy(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_yy(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_yy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_yy(np,counter);
    end
    end
    %}
    
    tauyyCorr_Mat_bottom(II,np) = correction1;
end    
    
end

%dv/dy
dvdy_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdy_bottom(II,1) = correction1;
end

dvdy_Mat_bottom = zeros(N,n_V_y);

for np = 1:1:n_V_y  

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdy_Mat_bottom(II,np) = correction1;
end
    
end

%Tauxy
tauxyCorr_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xy(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xy(counter,1);
    end
    end
    
    %{   
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xy(counter,1);
    end
    end
    %}
    
    tauxyCorr_bottom(II,1) = correction1;
end

tauxyCorr_Mat_bottom = zeros(N,n_C_xy);

for np = 1:1:n_C_xy 

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xy(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xy(np,counter);
    end
    end
    
    %{   
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xy(np,counter);
    end
    end
    %}
    
    tauxyCorr_Mat_bottom(II,np) = correction1;
end  
    
end

%du/dy
dudy_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudy_bottom(II,1) = correction1;
end

dudy_Mat_bottom = zeros(N,n_V_x);

for np = 1:1:n_V_x

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudy_Mat_bottom(II,np) = correction1;
end
    
end

%dv/dx
dvdx_bottom = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdx_bottom(II,1) = correction1;
end

dvdx_Mat_bottom = zeros(N,n_V_y);

for np = 1:1:n_V_y 

for II = 1:N
    x_grid = y(II);
    y_grid = -0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdx_Mat_bottom(II,np) = correction1;
end 
    
end

%Top wall:

%Tauxx
tauxxCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xx(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xx(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xx(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xx(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xx(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xx(counter,1);
    end
    end
    %}
    
    tauxxCorr_top(II,1) = correction1;
end

tauxxCorr_Mat_top = zeros(N,n_C_xx);

for np = 1:1:n_C_xx

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xx(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xx(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xx(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xx(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xx(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xx(np,counter);
    end
    end
    %}
    
    tauxxCorr_Mat_top(II,np) = correction1;
end
    
end

%du/dx
dudx_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_x(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}

    dudx_top(II,1) = correction1;
end

dudx_Mat_top = zeros(N,n_V_x);

for np = 1:1:n_V_x    

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_x(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}

    dudx_Mat_top(II,np) = correction1;
end 
    
end

%Tauyy
tauyyCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_yy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_yy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_yy(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_yy(counter,1);
    end
    end
	
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_yy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_yy(counter,1);
    end
    end
    %}

    tauyyCorr_top(II,1) = correction1;
end

tauyyCorr_Mat_top = zeros(N,n_C_yy);

for np = 1:1:n_C_yy  

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_yy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_yy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_yy(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_yy(np,counter);
    end
    end
	
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_yy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_yy(np,counter);
    end
    end
    %}

     tauyyCorr_Mat_top(II,np) = correction1;
end    
    
end

%dv/dy
dvdy_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdy_top(II,1) = correction1;
end

dvdy_Mat_top = zeros(N,n_V_y);

for np = 1:1:n_V_y   

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
    
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdy_Mat_top(II,np) = correction1;
end
    
end

%Tauxy
tauxyCorr_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*mN_C_xy(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*mN_C_xy(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*mN_C_xy(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*mN_C_xy(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*mN_C_xy(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*mN_C_xy(counter,1);
    end
    end
    %}
    
    tauxyCorr_top(II,1) = correction1;
end

tauxyCorr_Mat_top = zeros(N,n_C_xy);

for np = 1:1:n_C_xy 

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    correction1 = correction1 + RBF_x_level1*RBF_y_level1*R_C_xy(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    correction1 = correction1 + RBF_x_level2*RBF_y_level2*R_C_xy(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    correction1 = correction1 + RBF_x_level3*RBF_y_level3*R_C_xy(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    correction1 = correction1 + RBF_x_level4*RBF_y_level4*R_C_xy(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    correction1 = correction1 + RBF_x_level5*RBF_y_level5*R_C_xy(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    correction1 = correction1 + RBF_x_level6*RBF_y_level6*R_C_xy(np,counter);
    end
    end
    %}
    
    tauxyCorr_Mat_top(II,np) = correction1;
end  
    
end

%du/dy
dudy_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*mN_V_x(counter,1);
    end 
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*mN_V_x(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*mN_V_x(counter,1);
    end
    end
  
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*mN_V_x(counter,1);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*mN_V_x(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*mN_V_x(counter,1);
    end
    end
    %}
    
    dudy_top(II,1) = correction1;
end

dudy_Mat_top = zeros(N,n_V_x);

for np = 1:1:n_V_x   

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_y_level1 = (-2*var_rbf_level1)*(y_grid-Ci_level1_2(counter1,2));
    correction1 = correction1 + RBF_x_level1*Factor_y_level1*RBF_y_level1*R_V_x(np,counter);
    end 
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_y_level2 = (-2*var_rbf_level2)*(y_grid-Ci_level2_2(counter2,2));
    correction1 = correction1 + RBF_x_level2*Factor_y_level2*RBF_y_level2*R_V_x(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_y_level3 = (-2*var_rbf_level3)*(y_grid-Ci_level3_2(counter3,2));
    correction1 = correction1 + RBF_x_level3*Factor_y_level3*RBF_y_level3*R_V_x(np,counter);
    end
    end
  
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_y_level4 = (-2*var_rbf_level4)*(y_grid-Ci_level4_2(counter4,2));
    correction1 = correction1 + RBF_x_level4*Factor_y_level4*RBF_y_level4*R_V_x(np,counter);
    end
    end
    
    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_y_level5 = (-2*var_rbf_level5)*(y_grid-Ci_level5_2(counter5,2));
    correction1 = correction1 + RBF_x_level5*Factor_y_level5*RBF_y_level5*R_V_x(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_y_level6 = (-2*var_rbf_level6)*(y_grid-Ci_level6_2(counter6,2));
    correction1 = correction1 + RBF_x_level6*Factor_y_level6*RBF_y_level6*R_V_x(np,counter);
    end
    end
    %}
    
    dudy_Mat_top(II,np) = correction1;
end
    
end

%dv/dx
dvdx_top = zeros(N,1);

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*mN_V_y(counter,1);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*mN_V_y(counter,1);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*mN_V_y(counter,1);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*mN_V_y(counter,1);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*mN_V_y(counter,1);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*mN_V_y(counter,1);
    end
    end
    %}
    
    dvdx_top(II,1) = correction1;
end

dvdx_Mat_top = zeros(N,n_V_y);

for np = 1:1:n_V_y 

for II = 1:N
    x_grid = y(II);
    y_grid = 0.5;

    correction1 = 0;
    counter = 0;

    %Level 1:
    for counter1 = 1:NumRBFs_Level1
    distance_x_RBF = abs(Ci_level1_2(counter1,1));
    distance_y_RBF = abs(Ci_level1_2(counter1,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level1 = exp(-var_rbf_level1*(abs((y_grid-Ci_level1_2(counter1,2))).^2));
    RBF_x_level1 = exp(-var_rbf_level1*(abs((x_grid-Ci_level1_2(counter1,1))).^2));
    Factor_x_level1 = (-2*var_rbf_level1)*(x_grid-Ci_level1_2(counter1,1));
    correction1 = correction1 + Factor_x_level1*RBF_x_level1*RBF_y_level1*R_V_y(np,counter);
    end    
    end
    
    %Level 2:
    for counter2 = 1:NumRBFs_Level2
    distance_x_RBF = abs(Ci_level2_2(counter2,1));
    distance_y_RBF = abs(Ci_level2_2(counter2,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level2 = exp(-var_rbf_level2*(abs((y_grid-Ci_level2_2(counter2,2))).^2));
    RBF_x_level2 = exp(-var_rbf_level2*(abs((x_grid-Ci_level2_2(counter2,1))).^2));
    Factor_x_level2 = (-2*var_rbf_level2)*(x_grid-Ci_level2_2(counter2,1));
    correction1 = correction1 + Factor_x_level2*RBF_x_level2*RBF_y_level2*R_V_y(np,counter);
    end
    end
    
    %Level 3:
    for counter3 = 1:NumRBFs_Level3
    distance_x_RBF = abs(Ci_level3_2(counter3,1));
    distance_y_RBF = abs(Ci_level3_2(counter3,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level3 = exp(-var_rbf_level3*(abs((y_grid-Ci_level3_2(counter3,2))).^2));
    RBF_x_level3 = exp(-var_rbf_level3*(abs((x_grid-Ci_level3_2(counter3,1))).^2));
    Factor_x_level3 = (-2*var_rbf_level3)*(x_grid-Ci_level3_2(counter3,1));
    correction1 = correction1 + Factor_x_level3*RBF_x_level3*RBF_y_level3*R_V_y(np,counter);
    end
    end
   
    %Level 4:
    for counter4 = 1:NumRBFs_Level4
    distance_x_RBF = abs(Ci_level4_2(counter4,1));
    distance_y_RBF = abs(Ci_level4_2(counter4,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )    
    counter = counter + 1;    
    RBF_y_level4 = exp(-var_rbf_level4*(abs((y_grid-Ci_level4_2(counter4,2))).^2));
    RBF_x_level4 = exp(-var_rbf_level4*(abs((x_grid-Ci_level4_2(counter4,1))).^2));
    Factor_x_level4 = (-2*var_rbf_level4)*(x_grid-Ci_level4_2(counter4,1));
    correction1 = correction1 + Factor_x_level4*RBF_x_level4*RBF_y_level4*R_V_y(np,counter);
    end
    end

    %{    
    %Level 5:
    for counter5 = 1:NumRBFs_Level5
    distance_x_RBF = abs(Ci_level5_2(counter5,1));
    distance_y_RBF = abs(Ci_level5_2(counter5,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level5 = exp(-var_rbf_level5*(abs((y_grid-Ci_level5_2(counter5,2))).^2));
    RBF_x_level5 = exp(-var_rbf_level5*(abs((x_grid-Ci_level5_2(counter5,1))).^2));
    Factor_x_level5 = (-2*var_rbf_level5)*(x_grid-Ci_level5_2(counter5,1));
    correction1 = correction1 + Factor_x_level5*RBF_x_level5*RBF_y_level5*R_V_y(np,counter);
    end
    end

    %Level 6:
    for counter6 = 1:NumRBFs_Level6
    distance_x_RBF = abs(Ci_level6_2(counter6,1));
    distance_y_RBF = abs(Ci_level6_2(counter6,2));   
    if ( (distance_x_RBF >= (0.5 - Cutoff_Distance)) || (distance_y_RBF >= (0.5 - Cutoff_Distance)) )
    counter = counter + 1;    
    RBF_y_level6 = exp(-var_rbf_level6*(abs((y_grid-Ci_level6_2(counter6,2))).^2));
    RBF_x_level6 = exp(-var_rbf_level6*(abs((x_grid-Ci_level6_2(counter6,1))).^2));
    Factor_x_level6 = (-2*var_rbf_level6)*(x_grid-Ci_level6_2(counter6,1));
    correction1 = correction1 + Factor_x_level6*RBF_x_level6*RBF_y_level6*R_V_y(np,counter);
    end
    end
    %}
    
    dvdx_Mat_top(II,np) = correction1;
end 
    
end

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Exact_Boundary_Data_nsample_0_2.dat']);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n', ...
    tauxxCorr_left(I,1), dudx_left(I,1), tauyyCorr_left(I,1), dvdy_left(I,1), tauxyCorr_left(I,1), dudy_left(I,1), dvdx_left(I,1), ...
    tauxxCorr_right(I,1), dudx_right(I,1), tauyyCorr_right(I,1), dvdy_right(I,1), tauxyCorr_right(I,1), dudy_right(I,1), dvdx_right(I,1), ...
    tauxxCorr_bottom(I,1), dudx_bottom(I,1), tauyyCorr_bottom(I,1), dvdy_bottom(I,1), tauxyCorr_bottom(I,1), dudy_bottom(I,1), dvdx_bottom(I,1), ...
    tauxxCorr_top(I,1), dudx_top(I,1), tauyyCorr_top(I,1), dvdy_top(I,1), tauxyCorr_top(I,1), dudy_top(I,1), dvdx_top(I,1));
end
fclose(fileID);

for nn = 1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Exact_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'w');
for I = 1:N
fprintf(fileID,'%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g\n', ...
    tauxxCorr_Mat_left(I,nn), dudx_Mat_left(I,nn), tauyyCorr_Mat_left(I,nn), dvdy_Mat_left(I,nn), tauxyCorr_Mat_left(I,nn), dudy_Mat_left(I,nn), dvdx_Mat_left(I,nn), ...
    tauxxCorr_Mat_right(I,nn), dudx_Mat_right(I,nn), tauyyCorr_Mat_right(I,nn), dvdy_Mat_right(I,nn), tauxyCorr_Mat_right(I,nn), dudy_Mat_right(I,nn), dvdx_Mat_right(I,nn), ...
    tauxxCorr_Mat_bottom(I,nn), dudx_Mat_bottom(I,nn), tauyyCorr_Mat_bottom(I,nn), dvdy_Mat_bottom(I,nn), tauxyCorr_Mat_bottom(I,nn), dudy_Mat_bottom(I,nn), dvdx_Mat_bottom(I,nn), ...
    tauxxCorr_Mat_top(I,nn), dudx_Mat_top(I,nn), tauyyCorr_Mat_top(I,nn), dvdy_Mat_top(I,nn), tauxyCorr_Mat_top(I,nn), dudy_Mat_top(I,nn), dvdx_Mat_top(I,nn));
end
fclose(fileID);

end

%% Finite Differences Stress Corrections Calculation %%

%{
dudx = zeros(N,N);
dvdy = zeros(N,N);
dudy = zeros(N,N);
dvdx = zeros(N,N);

dx = h/N;
dy = h/N;

%Interior:

for II = 2:(N-1)
for JJ = 2:(N-1)
dudx(II,JJ) = (U_fit(II+1,JJ) - U_fit(II-1,JJ))/(2*dx);
dvdy(II,JJ) = (V_fit(II,JJ+1) - V_fit(II,JJ-1))/(2*dy);
dudy(II,JJ) = (U_fit(II,JJ+1) - U_fit(II,JJ-1))/(2*dy);
dvdx(II,JJ) = (V_fit(II+1,JJ) - V_fit(II-1,JJ))/(2*dx);
end
end

%Boundaries:

for JJ = 2:(N-1)

%dudx(1,JJ) = ( (U_fit(2,JJ)) - ((U_fit(1,JJ))) )/(dx);
dudx(1,JJ) = ( (-3*U_fit(1,JJ)) + (4*(U_fit(2,JJ))) - (U_fit(3,JJ)))/(2*dx);
%dudx(N,JJ) = ( (U_fit(N,JJ)) - ((U_fit(N-1,JJ))) )/(dx);
dudx(N,JJ) = ( (3*U_fit(N,JJ)) - (4*(U_fit(N-1,JJ))) + (U_fit(N-2,JJ)))/(2*dx);

dvdy(1,JJ) = ( (V_fit(1,JJ+1)) - ((V_fit(1,JJ-1))) )/(2*dy);
dvdy(N,JJ) = ( (V_fit(N,JJ+1)) - ((V_fit(N,JJ-1))) )/(2*dy);

dudy(1,JJ) = (U_fit(1,JJ+1) - U_fit(1,JJ-1))/(2*dy);
dudy(N,JJ) = (U_fit(N,JJ+1) - U_fit(N,JJ-1))/(2*dy);

%dvdx(1,JJ) = ( (V_fit(2,JJ)) - ((V_fit(1,JJ))) )/(dx);
dvdx(1,JJ) = ( (-3*V_fit(1,JJ)) + (4*(V_fit(2,JJ))) - (V_fit(3,JJ)))/(2*dx);
%dvdx(N,JJ) = ( (V_fit(N,JJ)) - ((V_fit(N-1,JJ))) )/(dx);
dvdx(N,JJ) = ( (3*V_fit(N,JJ)) - (4*(V_fit(N-1,JJ))) + (V_fit(N-2,JJ)))/(2*dx);

end

for II = 2:(N-1)

dudx(II,1) = (U_fit(II+1,1) - U_fit(II-1,1))/(2*dx);
dudx(II,N) = (U_fit(II+1,N) - U_fit(II-1,N))/(2*dx);

%dvdy(II,1) = (V_fit(II,2) - V_fit(II,1))/(dy);
dvdy(II,1) = ( (-3*V_fit(II,1)) + (4*(V_fit(II,2))) - (V_fit(II,3)))/(2*dy);
%dvdy(II,N) = (V_fit(II,N) - V_fit(II,N-1))/(dy);
dvdy(II,N) = ( (3*V_fit(II,N)) - (4*(V_fit(II,N-1))) + (V_fit(II,N-2)))/(2*dy);

%dudy(II,1) = (U_fit(II,2) - U_fit(II,1))/(dy);
dudy(II,1) = ( (-3*U_fit(II,1)) + (4*(U_fit(II,2))) - (U_fit(II,3)))/(2*dy);
%dudy(II,N) = (U_fit(II,N) - U_fit(II,N-1))/(dy);
dudy(II,N) = ( (3*U_fit(II,N)) - (4*(U_fit(II,N-1))) + (U_fit(II,N-2)))/(2*dy);

dvdx(II,1) = (V_fit(II+1,1) - V_fit(II-1,1))/(2*dx);
dvdx(II,N) = (V_fit(II+1,N) - V_fit(II-1,N))/(2*dx);

end

%Corners:

%dudx(1,1) = (U_fit(2,1) - U_fit(1,1))/(dx);
dudx(1,1) = ( (-3*U_fit(1,1)) + (4*(U_fit(2,1))) - (U_fit(3,1)))/(2*dx);
%dvdy(1,1) = (V_fit(1,2) - V_fit(1,1))/(dx);
dvdy(1,1) = ( (-3*V_fit(1,1)) + (4*(V_fit(1,2))) - (V_fit(1,3)))/(2*dy);
%dudy(1,1) = (U_fit(1,2) - U_fit(1,1))/(dy);
dudy(1,1) = ( (-3*U_fit(1,1)) + (4*(U_fit(1,2))) - (U_fit(1,3)))/(2*dy);
%dvdx(1,1) = ( (V_fit(2,1)) - ((V_fit(1,1))) )/(dx);
dvdx(1,1) = ( (-3*V_fit(1,1)) + (4*(V_fit(2,1))) - (V_fit(3,1)))/(2*dx);

%dudx(N,1) = ( (U_fit(N,1)) - ((U_fit(N-1,1))) )/(dx);
dudx(N,1) = ( (3*U_fit(N,1)) - (4*(U_fit(N-1,1))) + (U_fit(N-2,1)))/(2*dx);
%dvdy(N,1) = (V_fit(N,2) - V_fit(N,1))/(dy);
dvdy(N,1) = ( (-3*V_fit(N,1)) + (4*(V_fit(N,2))) - (V_fit(N,3)))/(2*dy);
%dudy(N,1) = (U_fit(N,2) - U_fit(N,1))/(dy);
dudy(N,1) = ( (-3*U_fit(N,1)) + (4*(U_fit(N,2))) - (U_fit(N,3)))/(2*dy);
%dvdx(N,1) = ( (V_fit(N,1)) - ((V_fit(N-1,1))) )/(dx);
dvdx(N,1) = ( (3*V_fit(N,1)) - (4*(V_fit(N-1,1))) + (V_fit(N-2,1)))/(2*dx);

%dudx(1,N) = ( (U_fit(2,N)) - ((U_fit(1,N))) )/(dx);
dudx(1,N) = ( (-3*V_fit(1,N)) + (4*(V_fit(2,N))) - (V_fit(3,N)))/(2*dx);
%dvdy(1,N) = (V_fit(1,N) - V_fit(1,N-1))/(dy);
dvdy(1,N) = ( (3*V_fit(1,N)) - (4*(V_fit(1,N-1))) + (V_fit(1,N-2)))/(2*dy);
%dudy(1,N) = (U_fit(1,N) - U_fit(1,N-1))/(dy);
dudy(1,N) = ( (3*U_fit(1,N)) - (4*(U_fit(1,N-1))) + (U_fit(1,N-2)))/(2*dy);
%dvdx(1,N) = ( (V_fit(2,N)) - ((V_fit(1,N))) )/(dx);
dvdx(1,N) = ( (-3*V_fit(1,N)) + (4*(V_fit(2,N))) - (V_fit(3,N)))/(2*dx);

%dudx(N,N) = ( (U_fit(N,N)) - ((U_fit(N-1,N))) )/(dx);
dudx(N,N) = ( (3*U_fit(N,N)) - (4*(U_fit(N-1,N))) + (U_fit(N-2,N)))/(2*dx);
%dvdy(N,N) = (V_fit(N,N) - V_fit(N,N-1))/(dy);
dvdy(N,N) = ( (3*V_fit(N,N)) - (4*(V_fit(N,N-1))) + (V_fit(N,N-2)))/(2*dy);
%dudy(N,N) = (U_fit(N,N) - U_fit(N,N-1))/(dy);
dudy(N,N) = ( (3*U_fit(N,N)) - (4*(U_fit(N,N-1))) + (U_fit(N,N-2)))/(2*dy);
%dvdx(N,N) = ( (V_fit(N,N)) - ((V_fit(N-1,N))) )/(dx);
dvdx(N,N) = ( (3*V_fit(N,N)) - (4*(V_fit(N-1,N))) + (V_fit(N-2,N)))/(2*dx);

muE = 2.117e-5;  

phixx(1:N,1:N) = tauxx(1:N,1:N) + (2*muE*dudx(1:N,1:N));
phiyy(1:N,1:N) = tauyy(1:N,1:N) + (2*muE*dvdy(1:N,1:N));
phixy(1:N,1:N) = tauxy(1:N,1:N) + (muE*(dudy(1:N,1:N) + dvdx(1:N,1:N)));

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phixx');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phixx';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phiyy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phiyy';
axis square;
axis tight;

figure;
hold on;
[X,Y] = meshgrid(x,y);
contourf(X,Y,phixy');
xlabel('x');
ylabel('y');
c = colorbar;
c.Label.String = 'phixy';
axis square;
axis tight;

%}

%toc
