
clear all;
close all;

N = 50;
nsample = 50;

for nn = 0:1:nsample

%filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Approx_Boundary_Data_nsample_%d_2.dat'],nn);
filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Pressure_Exact_Boundary_Data_nsample_%d_2.dat'],nn);
fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g';
sizeBoundaryData = [4 N];
Pressure_Boundary_Data = fscanf(fileID,formatSpec,sizeBoundaryData);
fclose(fileID);

massrho = (6.63e-26)*(1.2944e19); %Kn = 0.1
Pressure_Boundary_Data = Pressure_Boundary_Data';
Pressure_Boundary_Data = Pressure_Boundary_Data/massrho;
p_left = Pressure_Boundary_Data(:,1);
p_right = Pressure_Boundary_Data(:,2);
p_bottom = Pressure_Boundary_Data(:,3);
p_top = Pressure_Boundary_Data(:,4);

filename = sprintf(['0/pressureCorrections_nsample_%d'],nn);
fileID = fopen(filename,'w');
fprintf(fileID,'fixedWalls\n');
fprintf(fileID,'List<scalar>\n');
fprintf(fileID,'150\n');
fprintf(fileID,'(\n');

for i = 1:1:150

if ( (i >= 1) && (i <= 50) )

fprintf(fileID,'%g\n', p_left(i,1));

elseif ( (i >= 51) && (i <= 100) )    

fprintf(fileID,'%g\n', p_right(i-50,1));

elseif ( (i >= 101) && (i <= 150) )    

fprintf(fileID,'%g\n', p_bottom(i-100,1));

end    

end

fprintf(fileID,');\n');

fprintf(fileID,'topWall\n');
fprintf(fileID,'List<scalar>\n');
fprintf(fileID,'50\n');
fprintf(fileID,'(\n');

for i = 1:1:50

fprintf(fileID,'%g\n', p_top(i,1));

end

fprintf(fileID,');\n');

fclose(fileID);

end
