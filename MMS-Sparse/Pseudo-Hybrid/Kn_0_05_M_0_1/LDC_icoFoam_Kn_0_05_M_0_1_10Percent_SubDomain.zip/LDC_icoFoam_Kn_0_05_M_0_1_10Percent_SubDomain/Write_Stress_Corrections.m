
clear all;
close all;

N = 50;
nsample = 50;

for nn = 0:1:nsample

filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Interior_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g %g %g %g';
sizeInteriorStressData = [7 (N*N)];
Stress_Interior_Data = fscanf(fileID,formatSpec,sizeInteriorStressData);
fclose(fileID);

massrho = (6.63e-26)*(2.5888e19); %Kn = 0.05
Stress_Interior_Data = Stress_Interior_Data';
Stress_Interior_Data = Stress_Interior_Data/massrho;
tauxxCorr_2 = Stress_Interior_Data(:,1);
epsilonxxCorr_2 = Stress_Interior_Data(:,2);
tauyyCorr_2 = Stress_Interior_Data(:,3);
epsilonyyCorr_2 = Stress_Interior_Data(:,4);
tauxyCorr_2 = Stress_Interior_Data(:,5);
epsilonxyCorr_2 = Stress_Interior_Data(:,6);
epsilonyxCorr_2 = Stress_Interior_Data(:,7);

stressCorrxx = zeros(N*N,1);
stressCorryy = zeros(N*N,1);
stressCorrxy = zeros(N*N,1);

muE = 2.117e-5;

for i = 1:1:(N*N)
stressCorrxx(i,1) = tauxxCorr_2(i,1) + (2*muE*epsilonxxCorr_2(i,1));
stressCorryy(i,1) = tauyyCorr_2(i,1) + (2*muE*epsilonyyCorr_2(i,1));
stressCorrxy(i,1) = tauxyCorr_2(i,1) + (muE*( epsilonxyCorr_2(i,1) + epsilonyxCorr_2(i,1) ));
end

stressCorrxx(isnan(stressCorrxx))=0;
stressCorryy(isnan(stressCorryy))=0;
stressCorrxy(isnan(stressCorrxy))=0;

%filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Approx_Boundary_Data_nsample_%d_2.dat'],nn);
filename = sprintf(['10_Percent_SubDomain_CredibleIntervals/SparseBayes_2_17x17RBFs_Stress_Corrections_Exact_Boundary_Data_nsample_%d_2.dat'],nn);

fileID = fopen(filename,'r');
formatSpec = '%g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g %g';
sizeBoundaryStressData = [28 N];
Stress_Boundary_Data = fscanf(fileID,formatSpec,sizeBoundaryStressData);
fclose(fileID);

Stress_Boundary_Data = Stress_Boundary_Data';
Stress_Boundary_Data = Stress_Boundary_Data/massrho;

tauxxCorr_2_left = Stress_Boundary_Data(:,1);
epsilonxxCorr_2_left = Stress_Boundary_Data(:,2);
tauyyCorr_2_left = Stress_Boundary_Data(:,3);
epsilonyyCorr_2_left = Stress_Boundary_Data(:,4);
tauxyCorr_2_left = Stress_Boundary_Data(:,5);
epsilonxyCorr_2_left = Stress_Boundary_Data(:,6);
epsilonyxCorr_2_left = Stress_Boundary_Data(:,7);

tauxxCorr_2_right = Stress_Boundary_Data(:,8);
epsilonxxCorr_2_right = Stress_Boundary_Data(:,9);
tauyyCorr_2_right = Stress_Boundary_Data(:,10);
epsilonyyCorr_2_right = Stress_Boundary_Data(:,11);
tauxyCorr_2_right = Stress_Boundary_Data(:,12);
epsilonxyCorr_2_right = Stress_Boundary_Data(:,13);
epsilonyxCorr_2_right = Stress_Boundary_Data(:,14);

tauxxCorr_2_bottom = Stress_Boundary_Data(:,15);
epsilonxxCorr_2_bottom = Stress_Boundary_Data(:,16);
tauyyCorr_2_bottom = Stress_Boundary_Data(:,17);
epsilonyyCorr_2_bottom = Stress_Boundary_Data(:,18);
tauxyCorr_2_bottom = Stress_Boundary_Data(:,19);
epsilonxyCorr_2_bottom = Stress_Boundary_Data(:,20);
epsilonyxCorr_2_bottom = Stress_Boundary_Data(:,21);

tauxxCorr_2_top = Stress_Boundary_Data(:,22);
epsilonxxCorr_2_top = Stress_Boundary_Data(:,23);
tauyyCorr_2_top = Stress_Boundary_Data(:,24);
epsilonyyCorr_2_top = Stress_Boundary_Data(:,25);
tauxyCorr_2_top = Stress_Boundary_Data(:,26);
epsilonxyCorr_2_top = Stress_Boundary_Data(:,27);
epsilonyxCorr_2_top = Stress_Boundary_Data(:,28);

stressCorrxx_left = zeros(N,1);
stressCorryy_left = zeros(N,1);
stressCorrxy_left = zeros(N,1);
stressCorrxx_right = zeros(N,1);
stressCorryy_right = zeros(N,1);
stressCorrxy_right = zeros(N,1);
stressCorrxx_bottom = zeros(N,1);
stressCorryy_bottom = zeros(N,1);
stressCorrxy_bottom = zeros(N,1);
stressCorrxx_top = zeros(N,1);
stressCorryy_top = zeros(N,1);
stressCorrxy_top = zeros(N,1);

for i = 1:1:N

stressCorrxx_left(i,1) = tauxxCorr_2_left(i,1) + (2*muE*epsilonxxCorr_2_left(i,1));
stressCorryy_left(i,1) = tauyyCorr_2_left(i,1) + (2*muE*epsilonyyCorr_2_left(i,1));
stressCorrxy_left(i,1) = tauxyCorr_2_left(i,1) + (muE*( epsilonxyCorr_2_left(i,1) + epsilonyxCorr_2_left(i,1) ));

stressCorrxx_right(i,1) = tauxxCorr_2_right(i,1) + (2*muE*epsilonxxCorr_2_right(i,1));
stressCorryy_right(i,1) = tauyyCorr_2_right(i,1) + (2*muE*epsilonyyCorr_2_right(i,1));
stressCorrxy_right(i,1) = tauxyCorr_2_right(i,1) + (muE*( epsilonxyCorr_2_right(i,1) + epsilonyxCorr_2_right(i,1) ));

stressCorrxx_bottom(i,1) = tauxxCorr_2_bottom(i,1) + (2*muE*epsilonxxCorr_2_bottom(i,1));
stressCorryy_bottom(i,1) = tauyyCorr_2_bottom(i,1) + (2*muE*epsilonyyCorr_2_bottom(i,1));
stressCorrxy_bottom(i,1) = tauxyCorr_2_bottom(i,1) + (muE*( epsilonxyCorr_2_bottom(i,1) + epsilonyxCorr_2_bottom(i,1) ));

stressCorrxx_top(i,1) = tauxxCorr_2_top(i,1) + (2*muE*epsilonxxCorr_2_top(i,1));
stressCorryy_top(i,1) = tauyyCorr_2_top(i,1) + (2*muE*epsilonyyCorr_2_top(i,1));
stressCorrxy_top(i,1) = tauxyCorr_2_top(i,1) + (muE*( epsilonxyCorr_2_top(i,1) + epsilonyxCorr_2_top(i,1) ));

end

filename = sprintf(['0/stressCorrections_nsample_%d'],nn);
fileID = fopen(filename,'w');
fprintf(fileID,'internalProfile\n');
fprintf(fileID,'List<tensor>\n');
fprintf(fileID,'2500\n');
fprintf(fileID,'(\n');

for I = 1:1:2500

% components { XX , XY , XZ , YX , YY , YZ , ZX , ZY , ZZ }
%phixx = stressCorrxx(I,1);
phixx = (1/2)*( stressCorrxx(I,1) - stressCorryy(I,1) );
phixy = stressCorrxy(I,1);
phixz = 0.0;
phiyx = stressCorrxy(I,1);
%phiyy = stressCorryy(I,1);
phiyy = (1/2)*( stressCorryy(I,1) - stressCorrxx(I,1) );
phiyz = 0.0;
phizx = 0.0;
phizy = 0.0;
phizz = 0.0;

fprintf(fileID,'(%g %g %g %g %g %g %g %g %g)\n', phixx, phixy, phixz, phiyx, phiyy, phiyz, phizx, phizy, phizz);

end

fprintf(fileID,');\n');

fprintf(fileID,'fixedProfile\n');
fprintf(fileID,'List<tensor>\n');
fprintf(fileID,'150\n');
fprintf(fileID,'(\n');

for I = 1:1:150

if ( (I >= 1) && (I <= 50) )

% components { XX , XY , XZ , YX , YY , YZ , ZX , ZY , ZZ }
%phixx = stressCorrxx_left(I,1);
phixx = (1/2)*( stressCorrxx_left(I,1) - stressCorryy_left(I,1) );
phixy = stressCorrxy_left(I,1);
phixz = 0.0;
phiyx = stressCorrxy_left(I,1);
%phiyy = stressCorryy_left(I,1);
phiyy = (1/2)*( stressCorryy_left(I,1) - stressCorrxx_left(I,1) );
phiyz = 0.0;
phizx = 0.0;
phizy = 0.0;
phizz = 0.0;
fprintf(fileID,'(%g %g %g %g %g %g %g %g %g)\n', phixx, phixy, phixz, phiyx, phiyy, phiyz, phizx, phizy, phizz);

elseif ( (I >= 51) && (I <= 100) )    

% components { XX , XY , XZ , YX , YY , YZ , ZX , ZY , ZZ }
%phixx = stressCorrxx_right(I-50,1);
phixx = (1/2)*( stressCorrxx_right(I-50,1) - stressCorryy_right(I-50,1) );
phixy = stressCorrxy_right(I-50,1);
phixz = 0.0;
phiyx = stressCorrxy_right(I-50,1);
%phiyy = stressCorryy_right(I-50,1);
phiyy = (1/2)*( stressCorryy_right(I-50,1) - stressCorrxx_right(I-50,1) );
phiyz = 0.0;
phizx = 0.0;
phizy = 0.0;
phizz = 0.0;
fprintf(fileID,'(%g %g %g %g %g %g %g %g %g)\n', phixx, phixy, phixz, phiyx, phiyy, phiyz, phizx, phizy, phizz);

elseif ( (I >= 101) && (I <= 150) )  

% components { XX , XY , XZ , YX , YY , YZ , ZX , ZY , ZZ }
%phixx = stressCorrxx_bottom(I-100,1);
phixx = (1/2)*( stressCorrxx_bottom(I-100,1) - stressCorryy_bottom(I-100,1) );
phixy = stressCorrxy_bottom(I-100,1);
phixz = 0.0;
phiyx = stressCorrxy_bottom(I-100,1);
%phiyy = stressCorryy_bottom(I-100,1);
phiyy = (1/2)*( stressCorryy_bottom(I-100,1) - stressCorrxx_bottom(I-100,1) );
phiyz = 0.0;
phizx = 0.0;
phizy = 0.0;
phizz = 0.0;
fprintf(fileID,'(%g %g %g %g %g %g %g %g %g)\n', phixx, phixy, phixz, phiyx, phiyy, phiyz, phizx, phizy, phizz);

end    

end

fprintf(fileID,');\n');

fprintf(fileID,'topProfile\n');
fprintf(fileID,'List<tensor>\n');
fprintf(fileID,'50\n');
fprintf(fileID,'(\n');

for I = 1:1:50

% components { XX , XY , XZ , YX , YY , YZ , ZX , ZY , ZZ }
%phixx = stressCorrxx_top(I,1);
phixx = (1/2)*( stressCorrxx_top(I,1) - stressCorryy_top(I,1) );
phixy = stressCorrxy_top(I,1);
phixz = 0.0;
phiyx = stressCorrxy_top(I,1);
%phiyy = stressCorryy_top(I,1);
phiyy = (1/2)*( stressCorryy_top(I,1) - stressCorrxx_top(I,1) );
phiyz = 0.0;
phizx = 0.0;
phizy = 0.0;
phizz = 0.0;

fprintf(fileID,'(%g %g %g %g %g %g %g %g %g)\n', phixx, phixy, phixz, phiyx, phiyy, phiyz, phizx, phizy, phizz);

end

fprintf(fileID,');\n');

fclose(fileID);

end